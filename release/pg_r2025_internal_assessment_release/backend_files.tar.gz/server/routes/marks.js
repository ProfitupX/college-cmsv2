import express from 'express';
import db from '../db.js';
import { verifyAuthToken, computePasswordFingerprint, isValidAdminFingerprint } from './auth.js';
import { resolveAuthoritativeRegulation, resolveRegulationDetails } from '../../src/utils/regulationResolver.js';

const router = express.Router();

// ── Security & Authentication Context Hygiene ─────────────────
// Never allow raw incoming client headers to spoof authenticated identity
router.use((req, _res, next) => {
  delete req.headers['x-user-id'];
  delete req.headers['x-staff-id'];
  delete req.headers['x-user-role'];
  next();
});

// Server-side authentication context resolver
// Derives identity from server middleware context or verified HMAC-SHA256 Bearer token
export function getAuthenticatedUser(req) {
  // 1. Direct server middleware context (if attached by test harness or upstream middleware)
  if (req.user && typeof req.user === 'object' && req.user.id) {
    return {
      id: String(req.user.id),
      role: req.user.role ? String(req.user.role).toLowerCase() : undefined,
      department: req.user.department ? String(req.user.department) : undefined,
      name: req.user.name ? String(req.user.name) : undefined,
      email: req.user.email ? String(req.user.email) : undefined,
      pwf: req.user.pwf ? String(req.user.pwf) : undefined
    };
  }
  if (req.user && typeof req.user === 'string' && req.user.trim()) {
    return { id: req.user.trim() };
  }
  if (req.session?.user && req.session.user.id) {
    return {
      id: String(req.session.user.id),
      role: req.session.user.role ? String(req.session.user.role).toLowerCase() : undefined,
      department: req.session.user.department ? String(req.session.user.department) : undefined,
      name: req.session.user.name ? String(req.session.user.name) : undefined,
      email: req.session.user.email ? String(req.session.user.email) : undefined,
      pwf: req.session.user.pwf ? String(req.session.user.pwf) : undefined
    };
  }

  // 2. Cryptographically verified Bearer token from Authorization header
  const authHeader = req.headers['authorization'];
  if (authHeader && typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    const rawToken = authHeader.slice(7).trim();
    const verified = verifyAuthToken(rawToken);
    if (verified && verified.id) {
      return {
        id: String(verified.id),
        email: verified.email ? String(verified.email) : undefined,
        role: verified.role ? String(verified.role).toLowerCase() : undefined,
        pwf: verified.pwf ? String(verified.pwf) : undefined
      };
    }
  }

  return null;
}

/**
 * Resolves acting staff record from database or existing hardcoded administrative accounts.
 * Hardcoded accounts (ADMIN, PRIN, VP) are explicitly recognized without requiring DB records.
 * Validates token password fingerprint against current database password hash (or admin credentials).
 * Rejects missing, outdated or mismatched fingerprints with 401 Unauthorized.
 * Never leaks the password hash in the returned record.
 */
export async function resolveActingStaff(database, userOrId, tokenFingerprintArg) {
  if (!userOrId) return null;

  let userId;
  let tokenFingerprint = tokenFingerprintArg;
  if (typeof userOrId === 'object' && userOrId !== null) {
    userId = userOrId.id;
    if (!tokenFingerprint && userOrId.pwf) {
      tokenFingerprint = userOrId.pwf;
    }
  } else {
    userId = userOrId;
  }

  if (!userId) return null;
  const uid = String(userId).trim();

  // Validate fingerprint presence
  if (!tokenFingerprint || typeof tokenFingerprint !== 'string' || !tokenFingerprint.trim()) {
    const authError = new Error('Unauthorized: Authentication token is missing password fingerprint. Please log in again.');
    authError.status = 401;
    throw authError;
  }
  const cleanFingerprint = tokenFingerprint.trim();

  // 1. Explicit handling for existing hardcoded administrative accounts
  if (uid === 'ADMIN' || uid === 'PRIN' || uid === 'VP') {
    if (!isValidAdminFingerprint(uid, cleanFingerprint)) {
      const authError = new Error('Unauthorized: Administrative authentication token is invalid or outdated. Please log in again.');
      authError.status = 401;
      throw authError;
    }

    if (uid === 'ADMIN') {
      return {
        id: 'ADMIN',
        name: 'Admin User',
        role: 'admin',
        department: 'College Administration'
      };
    }
    if (uid === 'PRIN') {
      return {
        id: 'PRIN',
        name: 'Dr. C. Mathalai Sundaram',
        role: 'principal',
        department: 'College Administration'
      };
    }
    if (uid === 'VP') {
      return {
        id: 'VP',
        name: 'Dr. M. Sathya',
        role: 'vice_principal',
        department: 'College Administration'
      };
    }
  }

  // 2. Query staff registry from MySQL including password hash
  const [rows] = await database.execute(
    'SELECT id, name, role, department, password FROM staffs WHERE id = ? OR LOWER(email) = LOWER(?)',
    [uid, uid]
  );
  if (!rows || rows.length === 0) {
    return null; // User not found in staff registry
  }

  const staff = rows[0];
  const currentDbFingerprint = computePasswordFingerprint(staff.password);

  if (!currentDbFingerprint || currentDbFingerprint !== cleanFingerprint) {
    const authError = new Error('Unauthorized: Password has been changed or token fingerprint is invalid. Please log in again.');
    authError.status = 401;
    throw authError;
  }

  // 3. Return sanitized staff object — NEVER leak or return the password hash!
  return {
    id: staff.id,
    name: staff.name,
    role: staff.role,
    department: staff.department
  };
}

// Canonical attendance mark calculation rule:
// >=95% -> 5, 90-94% -> 3, 85-89% -> 2, 80-84% -> 1, <80% -> 0
function getAttendanceMark(pct) {
  const p = Math.round(Number(pct) || 0);
  if (p >= 95) return 5;
  if (p >= 90) return 3;
  if (p >= 85) return 2;
  if (p >= 80) return 1;
  return 0;
}

// ─────────────────────────────────────────────────────────────
// Authoritative Department Definitions and Resolution
// RULE: The Subject's Department HOD ALWAYS has authority over freeze, unfreeze, and unlock approvals!
// ─────────────────────────────────────────────────────────────
export const CANONICAL_DEPARTMENTS = {
  CSE: 'Computer Science and Engineering',
  IT: 'Information Technology',
  ECE: 'Electronics and Communication Engineering',
  EEE: 'Electrical and Electronics Engineering',
  MECH: 'Mechanical Engineering',
  CIVIL: 'Civil Engineering',
  AIDS: 'Artificial Intelligence and Data Science',
  SH: 'Science and Humanities'
};

export function canonicalizeDepartment(dept) {
  if (!dept || typeof dept !== 'string') return null;
  const s = dept.trim().toLowerCase();
  if (!s) return null;

  // 1. Computer Science and Engineering
  if (s === 'cse' || s === 'cs' || s.includes('computer science')) {
    return CANONICAL_DEPARTMENTS.CSE;
  }
  // 2. Information Technology
  if (s === 'it' || s.includes('information technology') || s === 'infotech') {
    return CANONICAL_DEPARTMENTS.IT;
  }
  // 3. Artificial Intelligence and Data Science
  if (s === 'aids' || s === 'ai&ds' || s === 'ai & ds' || s === 'ad' || (s.includes('artificial') && s.includes('intelligence')) || s.includes('data science')) {
    return CANONICAL_DEPARTMENTS.AIDS;
  }
  // 4. Electronics and Communication Engineering
  if (s === 'ece' || s === 'ec' || s.includes('electronics and communication') || s.includes('electronics & communication')) {
    return CANONICAL_DEPARTMENTS.ECE;
  }
  // 5. Electrical and Electronics Engineering
  if (s === 'eee' || s === 'ee' || s.includes('electrical and electronics') || s.includes('electrical & electronics')) {
    return CANONICAL_DEPARTMENTS.EEE;
  }
  // 6. Mechanical Engineering
  if (s === 'mech' || s === 'me' || s.includes('mechanical')) {
    return CANONICAL_DEPARTMENTS.MECH;
  }
  // 7. Civil Engineering
  if (s === 'civil' || s === 'ce' || s.includes('civil')) {
    return CANONICAL_DEPARTMENTS.CIVIL;
  }
  // 8. Science and Humanities
  if (s === 's&h' || s === 's & h' || s === 'sh' || s.includes('science and humanities') || s.includes('science & humanities') || s === 'first year' || s.includes('maths') || s.includes('physics') || s.includes('chemistry') || s.includes('humanities')) {
    return CANONICAL_DEPARTMENTS.SH;
  }

  return null;
}

export function inferDepartmentFromSubjectCode(code) {
  if (!code || typeof code !== 'string') return null;
  const c = code.trim().toUpperCase();

  // 1. Longest / specific prefixes (3 characters)
  // Ensures CBM -> ECE (not CB -> CSE), CEC -> ECE (not CE -> Civil)
  if (/^(CBM|CEC)/.test(c)) {
    return CANONICAL_DEPARTMENTS.ECE;
  }
  if (/^CCS/.test(c)) {
    return CANONICAL_DEPARTMENTS.CSE;
  }
  if (/^(CME|CRA|OME|OML)/.test(c)) {
    return CANONICAL_DEPARTMENTS.MECH;
  }
  if (/^OGI/.test(c)) {
    return CANONICAL_DEPARTMENTS.CIVIL;
  }
  if (/^OHS/.test(c)) {
    return CANONICAL_DEPARTMENTS.SH;
  }

  // 2. Standard 2-character prefixes
  if (/^(MA|PH|CY|GE|HS|BS|UC|EN)/.test(c)) {
    return CANONICAL_DEPARTMENTS.SH;
  }
  if (/^(CS|CB|CP)/.test(c)) {
    return CANONICAL_DEPARTMENTS.CSE;
  }
  if (/^(IT|CW)/.test(c)) {
    return CANONICAL_DEPARTMENTS.IT;
  }
  if (/^AD/.test(c)) {
    return CANONICAL_DEPARTMENTS.AIDS;
  }
  if (/^EC/.test(c)) {
    return CANONICAL_DEPARTMENTS.ECE;
  }
  if (/^EE/.test(c)) {
    return CANONICAL_DEPARTMENTS.EEE;
  }
  if (/^ME/.test(c)) {
    return CANONICAL_DEPARTMENTS.MECH;
  }
  if (/^(CE|AG|GI)/.test(c)) {
    return CANONICAL_DEPARTMENTS.CIVIL;
  }

  return null;
}

/**
 * Resolves the owning canonical department of a class.
 * Handles both Undergraduate classes and all Postgraduate (M.E.) programmes.
 */
export function resolveClassOwningDepartment(cls) {
  if (!cls) return null;

  const clsId = String(cls.id || cls.class_id || '').trim();
  const clsName = String(cls.name || cls.class_name || '').trim().toUpperCase();
  const clsDept = String(cls.department || cls.class_department || '').trim();

  // 1. Postgraduate Programme Owning Departments
  // M.E. CSE
  if (
    clsId === 'CL_1794306342' || clsId === 'CL_1795140566' ||
    /^ME[_\-\/]CSE/i.test(clsId) ||
    (clsName.includes('CSE') && (clsName.includes('ME') || clsName.includes('M.E.')))
  ) {
    return CANONICAL_DEPARTMENTS.CSE;
  }

  // M.E. EST (Embedded System Technologies) -> ECE
  if (
    clsId === 'CL_1794909437' ||
    /^ME[_\-\/]EST/i.test(clsId) ||
    clsName.includes('EST') || clsName.includes('EMBEDDED')
  ) {
    return CANONICAL_DEPARTMENTS.ECE;
  }

  // M.E. Structural Engineering -> Civil
  if (
    clsId === 'CL_1794909933' || clsId === 'CL_1794909988' ||
    /^ME[_\-\/]SE/i.test(clsId) ||
    (/\bSE\b/.test(clsName) && (clsName.includes('ME') || clsName.includes('M.E.'))) ||
    clsName.includes('STRUCTURAL')
  ) {
    return CANONICAL_DEPARTMENTS.CIVIL;
  }

  // M.E. Manufacturing Engineering -> Mechanical
  if (
    clsId === 'CL_1794910479' || clsId === 'CL_1794910622' ||
    /^ME[_\-\/]MFE/i.test(clsId) ||
    clsName.includes('MFE') || clsName.includes('MANUFACTURING')
  ) {
    return CANONICAL_DEPARTMENTS.MECH;
  }

  // 2. Direct canonical department match (UG or standard department field)
  if (clsDept) {
    const canonical = canonicalizeDepartment(clsDept);
    if (canonical) return canonical;
  }

  return null;
}

export function getAuthoritativeSubjectDepartment(subject, targetClass = null) {
  if (!subject) return null;

  // 1. Primary source: subjects.department
  const rawDept = subject.department || subject.sub_dept;
  if (rawDept && typeof rawDept === 'string' && rawDept.trim()) {
    const canonical = canonicalizeDepartment(rawDept);
    if (canonical) return canonical;
  }

  // 2. Class-level Owning Department Fallback
  // If subject.department is null or unassigned, resolve from the associated class
  if (targetClass) {
    const classDept = resolveClassOwningDepartment(targetClass);
    if (classDept) return classDept;
  }

  // 3. Authoritative Fallback: Subject Code Prefix
  const fromCode = inferDepartmentFromSubjectCode(subject.code);
  if (fromCode) return fromCode;

  return null;
}

export function isPGClassEntity(cls) {
  if (!cls) return false;
  const clsId = String(cls.id || cls.class_id || '').trim();
  const clsName = String(cls.name || cls.class_name || '').trim().toUpperCase();

  // 1. Direct registry check for known PG Programme production/canonical IDs
  const pgProductionClassIds = [
    'CL_1794306342', 'CL_1795140566', // ME CSE
    'CL_1794909437',                  // ME EST
    'CL_1794909933', 'CL_1794909988', // ME SE
    'CL_1794910479', 'CL_1794910622'  // ME MFE
  ];
  if (pgProductionClassIds.includes(clsId)) return true;

  // 2. Explicit schema flags
  if (cls.program_type === 'PG' || cls.programType === 'PG' || cls.degree === 'PG' || cls.degree_type === 'PG') return true;
  if (cls.degree_title === 'M.E.' || cls.degree_title === 'M.Tech') return true;

  // 3. Class ID prefix patterns (ME_*, ME-*, PG_*)
  if (/^(ME|PG)[_\-\/]/i.test(clsId)) return true;

  // 4. Strict exclusion of Mechanical Engineering (UG MECH)
  if (/^MECH\b|^MECHANICAL\b/i.test(clsName)) return false;

  // 5. Class Name patterns with word boundaries
  if (/\bM\.?E\.?\b/.test(clsName)) return true;
  if (/\bM\.?TECH\b/i.test(clsName)) return true;
  if (/^ME[\s_\-\/:]/i.test(clsName)) return true;
  if (/\bPG[\s_\-\/:]/i.test(clsName) || /[\s_\-\/:]PG\b/i.test(clsName)) return true;

  // Default fail-closed: if PG status cannot be established authoritatively, return false
  return false;
}

export function isPGSubjectEntity(sub, cls) {
  // 1. Authoritative class check: if class is established as PG, the subject is PG
  if (cls && isPGClassEntity(cls)) return true;
  if (!sub) return false;

  // 2. Explicit subject-level schema flags
  if (sub.program_type === 'PG' || sub.programType === 'PG' || sub.degree === 'PG' || sub.degree_type === 'PG') return true;
  if (sub.degree_title === 'M.E.' || sub.degree_title === 'M.Tech') return true;

  // 3. Subject-associated class ID
  const clsIdStr = String(sub.class_id || '').trim();
  if (clsIdStr && isPGClassEntity({ id: clsIdStr })) return true;

  // 4. Subject-associated class name (joined from query)
  const clsNameStr = String(sub.class_name || sub.className || '').trim();
  if (clsNameStr && isPGClassEntity({ name: clsNameStr })) return true;

  // A UG Project subject must never be classified as PG solely because its subject type is Project.
  // If PG status cannot be established authoritatively, fail closed (return false).
  return false;
}

export function getPGR2025CiaMax(_subjectType) {
  return 95;
}

export function getDepartmentAliases(canonicalDept) {
  if (!canonicalDept) return [];
  switch (canonicalDept) {
    case CANONICAL_DEPARTMENTS.CSE:
      return ['Computer Science and Engineering', 'CSE', 'Computer Science & Engineering', 'CS'];
    case CANONICAL_DEPARTMENTS.IT:
      return ['Information Technology', 'IT'];
    case CANONICAL_DEPARTMENTS.ECE:
      return ['Electronics and Communication Engineering', 'ECE', 'Electronics & Communication Engineering', 'EC'];
    case CANONICAL_DEPARTMENTS.EEE:
      return ['Electrical and Electronics Engineering', 'EEE', 'Electrical & Electronics Engineering', 'EE'];
    case CANONICAL_DEPARTMENTS.MECH:
      return ['Mechanical Engineering', 'MECH', 'Mech', 'ME'];
    case CANONICAL_DEPARTMENTS.CIVIL:
      return ['Civil Engineering', 'CIVIL', 'Civil', 'CE'];
    case CANONICAL_DEPARTMENTS.AIDS:
      return ['Artificial Intelligence and Data Science', 'AI&DS', 'AIDS', 'AI & DS', 'AD'];
    case CANONICAL_DEPARTMENTS.SH:
      return ['Science and Humanities', 'S&H', 'First Year', 'Science & Humanities', 'S & H'];
    default:
      return [canonicalDept];
  }
}

export async function getDepartmentHod(database, canonicalDept) {
  const aliases = getDepartmentAliases(canonicalDept);
  const placeholders = aliases.map(() => '?').join(', ');
  const [rows] = await database.execute(
    `SELECT id, name, email, department, role
     FROM staffs
     WHERE role = 'hod' AND (
       department IN (${placeholders})
       OR LOWER(department) LIKE ?
     )
     ORDER BY id ASC
     LIMIT 1`,
    [...aliases, `%${canonicalDept.toLowerCase()}%`]
  );
  return rows[0] || null;
}

// Helper to resolve accurate department for notification targeting:
// MANDATORY RULE: The Subject's Department HOD ALWAYS has authority!
function resolveSubjectDepartment(sub, targetClass = null) {
  const authDept = getAuthoritativeSubjectDepartment(sub, targetClass);
  if (authDept) return authDept;
  return 'College Administration';
}

/**
 * Checks if a class belongs to an HOD's department or their owning PG programme.
 * Standardized across MarkHub authorization checks.
 */
export function isClassAuthorizedForHod(cls, hodDept) {
  if (!cls || !hodDept) return false;
  const hodCanonical = canonicalizeDepartment(hodDept);
  if (!hodCanonical) return false;

  const classOwningDept = resolveClassOwningDepartment(cls);
  if (classOwningDept && classOwningDept === hodCanonical) return true;

  // Direct match on raw department string
  const dStr = String(hodDept).trim().toLowerCase();
  const clsDept = String(cls.department || cls.class_department || '').trim().toLowerCase();
  if (clsDept === dStr) return true;

  return false;
}

// ─────────────────────────────────────────────────────────────
// Database Schema Capabilities & Dynamic Fallback Helper
// Ensures marks routes run safely on Phase 1 (markhub_db) and Phase 2 (markhub_phase2_test)
// without throwing "Unknown column 'exam_date' in 'field list'"
// ─────────────────────────────────────────────────────────────
let schemaCapabilities = null;
async function getSchemaCapabilities(conn, forceRefresh = false) {
  if (schemaCapabilities && !forceRefresh) return schemaCapabilities;
  try {
    const [cols] = await conn.execute(
      `SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'marks_sessions'`
    );
    const colSet = new Set(cols.map(c => c.COLUMN_NAME));

    schemaCapabilities = {
      hasExamDateCol: colSet.has('exam_date'),
      hasTotalHoursCol: colSet.has('total_hours'),
      hasInternal2TotalHoursCol: colSet.has('internal2_total_hours')
    };
  } catch (err) {
    schemaCapabilities = null; // Do NOT permanently cache failed metadata lookups!
    console.error('getSchemaCapabilities error querying INFORMATION_SCHEMA:', err.message);
    throw new Error(`Failed to query database schema capabilities: ${err.message}`);
  }
  return schemaCapabilities;
}
router.__resetSchemaCapabilities = () => { schemaCapabilities = null; };

// Helper to save exam date in system_settings when marks_sessions does not have exam_date column
// exam_date_<sessionId> is the SOLE authoritative source of truth
async function saveExamDateToSettings(conn, sessionId, _subjectId, _classId, _sessionLabel, examDate) {
  try {
    if (!sessionId) return;
    const settingKey = `exam_date_${sessionId}`;

    if (!examDate) {
      // Explicitly cleared date: remove authoritative individual session key
      await conn.execute(
        `DELETE FROM system_settings WHERE setting_key = ?`,
        [settingKey]
      );
      return;
    }

    const cleanDate = String(examDate).substring(0, 10);

    // Save authoritative individual session key using INSERT ... ON DUPLICATE KEY UPDATE
    await conn.execute(
      `INSERT INTO system_settings (setting_key, setting_value)
       VALUES (?, ?)
       ON DUPLICATE KEY UPDATE setting_value = ?`,
      [settingKey, cleanDate, cleanDate]
    );
  } catch (err) {
    console.error('saveExamDateToSettings error:', err.message);
    throw new Error(`Failed to persist exam date in settings: ${err.message}`);
  }
}

// Helper to resolve exam date from system_settings for a single session
// Reads exclusively from authoritative individual key exam_date_<sessionId>
async function resolveExamDateFromSettings(conn, sessionId, _subjectId, _classId, _sessionLabel) {
  if (!sessionId) return null;
  try {
    const [singleRow] = await conn.execute(
      `SELECT setting_value FROM system_settings WHERE setting_key = ? LIMIT 1`,
      [`exam_date_${sessionId}`]
    );
    if (singleRow.length > 0 && singleRow[0].setting_value) {
      return String(singleRow[0].setting_value).substring(0, 10);
    }
    return null; // Setting does not exist
  } catch (err) {
    console.error('resolveExamDateFromSettings error:', err.message);
    throw new Error(`Failed to resolve exam date from settings: ${err.message}`);
  }
}

// ─────────────────────────────────────────────────────────────
// POST /api/marks/submit
// Body: {
//   subjectId, classId, staffId, sessionLabel,
//   components: [{ typeId, label, maxMarks, icon, color, sortOrder }],
//   marks:      [{ studentId, componentIndex, marksObtained }]
// }
// ─────────────────────────────────────────────────────────────
router.post('/submit', async (req, res) => {
  const conn = await db.getConnection();
  try {
    // ── 1. Backend Authentication Context Verification ──
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      return res.status(401).json({ error: 'Authentication required to save marks.' });
    }

    let actingStaff;
    try {
      actingStaff = await resolveActingStaff(conn, authUser.id, authUser.pwf);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!actingStaff) {
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry.' });
    }

    await conn.beginTransaction();

    const { subjectId, classId, staffId, sessionLabel, components, marks, totalHours, internal2TotalHours, attendance, actionType, remedialAction, examDate } = req.body;

    if (!subjectId || !classId || !components) {
      await conn.rollback();
      return res.status(400).json({ error: 'Missing required fields.' });
    }

    const userRole = String(actingStaff.role || '').toLowerCase();
    const isPrivileged = ['admin', 'principal', 'vice_principal'].includes(userRole);

    const cleanExamDate = examDate && typeof examDate === 'string' && examDate.trim().length >= 10
      ? examDate.trim().substring(0, 10)
      : (examDate ? examDate : null);

    // Fetch subject details including class_id and faculty_id for assignment authorization
    const [subRows] = await conn.execute(
      'SELECT id, code, name, type, ltpc, total_hours, int1_hours, int2_hours, lab_hours, department, class_id, faculty_id FROM subjects WHERE id = ? OR code = ?',
      [subjectId, subjectId]
    );
    if (subRows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ error: 'Subject not found.' });
    }
    const subObj = subRows[0];

    // Verify Subject belongs to the requested class
    if (subObj.class_id && String(subObj.class_id) !== String(classId)) {
      await conn.rollback();
      return res.status(400).json({ error: 'Invalid class: Subject does not belong to the selected class.' });
    }

    // Fetch class details for authorization and regulation context
    const [clsRows] = await conn.execute('SELECT * FROM classes WHERE id = ? LIMIT 1', [classId]);
    const targetClass = clsRows.length > 0 ? clsRows[0] : null;

    const isPG = isPGClassEntity(targetClass) || isPGSubjectEntity(subObj, targetClass);
    const regResult = resolveRegulationDetails({
      classObj: targetClass,
      subject: subObj,
      isPG
    });

    if (!regResult.regulation) {
      await conn.rollback();
      return res.status(400).json({
        error: regResult.error || 'Academic regulation unresolved: Unable to authoritatively determine academic regulation from class and subject database metadata.'
      });
    }

    const is2021 = regResult.regulation === '2021';

    // Role-Based Assignment Authorization & Session Ownership Resolution
    let effectiveStaffId = actingStaff.id;
    if (isPrivileged) {
      // Privileged administrative accounts can submit on behalf of assigned faculty
      effectiveStaffId = staffId || subObj.faculty_id || actingStaff.id;
    } else if (userRole === 'hod') {
      const authDept = getAuthoritativeSubjectDepartment(subObj);
      const hodDept = actingStaff.department;
      const isDeptSubject = authDept && hodDept && (
        String(authDept).toLowerCase() === String(hodDept).toLowerCase() ||
        String(subObj.department || '').toLowerCase() === String(hodDept).toLowerCase()
      );

      // Check if class belongs to HOD's department or PG owning programme
      const isDeptClass = targetClass && isClassAuthorizedForHod(targetClass, hodDept);
      const isAssignedFaculty = String(subObj.faculty_id || '') === String(actingStaff.id);

      if (!isAssignedFaculty && !isDeptSubject && !isDeptClass) {
        await conn.rollback();
        return res.status(403).json({ error: 'Access denied: You do not have permission to enter marks for another department\'s subject or academic programme.' });
      }

      // Session owner validation: HOD can only submit under the subject's assigned faculty or the HOD themselves
      if (staffId && String(staffId).trim()) {
        const cleanStaffId = String(staffId).trim();
        const assignedFacId = subObj.faculty_id ? String(subObj.faculty_id).trim() : null;
        const hodId = String(actingStaff.id).trim();

        if (cleanStaffId !== hodId && (!assignedFacId || cleanStaffId !== assignedFacId)) {
          await conn.rollback();
          return res.status(403).json({ error: 'Unauthorized: Session owner must be the assigned faculty member or the authorized HOD.' });
        }
        effectiveStaffId = cleanStaffId;
      } else {
        effectiveStaffId = subObj.faculty_id || actingStaff.id;
      }
    } else if (userRole === 'faculty') {
      const isAssignedFaculty = String(subObj.faculty_id || '') === String(actingStaff.id);
      if (!isAssignedFaculty) {
        await conn.rollback();
        return res.status(403).json({ error: 'Access denied: You are not the assigned faculty for this subject.' });
      }
      // Prevent faculty impersonation: non-privileged users cannot spoof staffId
      if (staffId && String(staffId).trim() !== String(actingStaff.id).trim()) {
        await conn.rollback();
        return res.status(403).json({ error: 'Unauthorized: Cannot submit marks on behalf of another faculty member.' });
      }
      effectiveStaffId = actingStaff.id;
    } else {
      await conn.rollback();
      return res.status(403).json({ error: 'Access denied: Your role does not have mark-entry permissions.' });
    }
    const isPureLabSubmission = Boolean(
      subObj.type === 'Practical' ||
      subObj.type === 'Laboratory' ||
      subObj.type === 'Lab' ||
      (subObj.name && subObj.name.toLowerCase().includes('laboratory') && !['Lab-cum-Theory', 'Theory-cum-Lab', 'Lab cum Theory', 'Theory cum Lab'].includes(subObj.type))
    );

    const effInt1Hours = parseInt(req.body.int1Hours ?? subObj.int1_hours ?? 30, 10) || 30;
    const effInt2Hours = parseInt(req.body.int2Hours ?? subObj.int2_hours ?? 30, 10) || 30;
    const effLabHours  = parseInt(req.body.labHours ?? subObj.lab_hours ?? 0, 10) || 0;

    let sessionTotalHours = parseInt(totalHours, 10) || 0;
    if (sessionLabel === 'internal1') {
      sessionTotalHours = effInt1Hours;
    } else if (sessionLabel === 'internal2') {
      sessionTotalHours = effInt2Hours;
    } else if (isPureLabSubmission) {
      sessionTotalHours = effLabHours || (sessionTotalHours > 0 ? sessionTotalHours : subObj.total_hours || 60);
    } else if (!sessionTotalHours) {
      sessionTotalHours = 30;
    }

    const schema = await getSchemaCapabilities(conn);

    // 1.5 Find existing session using columns that exist in the active schema
    const selectFields = ['id', 'status', 'total_max'];
    if (schema.hasExamDateCol) selectFields.push('exam_date');

    const [existingSessions] = await conn.execute(
      `SELECT ${selectFields.join(', ')} FROM marks_sessions WHERE subject_id = ? AND class_id = ? AND session_label = ? ORDER BY id DESC`,
      [String(subjectId), String(classId), String(sessionLabel)]
    );
    const existingSession = existingSessions.length > 0 ? existingSessions[0] : null;

    // Guard locked/frozen session: values must NEVER change unless explicitly unlocked by authorized staff
    if (existingSession && (existingSession.status === 'locked' || existingSession.status === 'frozen')) {
      if (existingSession.status !== 'unlocked') {
        await conn.rollback();
        return res.status(403).json({ error: 'This marks sheet is locked and frozen. Values cannot be changed unless explicitly unlocked by authorized HOD or Admin.' });
      }
    }

    if (existingSession && actionType === 'clear' && (existingSession.status === 'locked' || existingSession.status === 'frozen')) {
      await conn.rollback();
      return res.status(403).json({ error: 'Cannot clear a locked or frozen marks sheet.' });
    }

    // If components is empty and user explicitly requests clear
    if (components.length === 0) {
      if (existingSession && actionType === 'clear') {
        await conn.execute(`DELETE FROM marks WHERE session_id = ?`, [existingSession.id]);
        await conn.execute(`DELETE FROM session_attendance WHERE session_id = ?`, [existingSession.id]);
        await conn.execute(`DELETE FROM assessment_components WHERE session_id = ?`, [existingSession.id]);
        await conn.execute(`UPDATE marks_sessions SET status = 'draft', avg_score = 0, updated_at = NOW() WHERE id = ?`, [existingSession.id]);
        await conn.commit();
        return res.json({ success: true, message: 'Marks sheet cleared successfully.' });
      }
      const hasAttendance = attendance && Array.isArray(attendance) && attendance.some(a => (a.hoursAttended || a.actualTakenHours || a.internalExamMark || a.labMark || a.labAttendance));
      if (!hasAttendance) {
        await conn.commit();
        return res.json({ success: true, message: 'No changes made.' });
      }
    }

    // 1. Calculate total max and avg score
    const totalMax = components.reduce((s, c) => s + (parseFloat(c.maxMarks) || 0), 0);

    // Common Autonomous R2025 Internal Assessment Structure (UG & PG):
    // When assessment components are configured, maximum staff allocation is strictly 95 marks across all course types
    // (Theory, Theory-cum-Lab, Practical/Laboratory, Project), with 5 marks strictly reserved for attendance (total internal = 100 marks).
    // In legacy pure-lab direct mark entry where no components are created (components.length === 0):
    // - For Autonomous R2025 (UG & PG), direct laboratory assessment mark cannot exceed 95 marks (5 marks reserved for attendance).
    // - For Regulation 2021, practical examination mark is written out of 100.
    const maxAllowedStaffAllocation = 95;
    if (components.length > 0 && totalMax > maxAllowedStaffAllocation) {
      await conn.rollback();
      return res.status(400).json({
        error: `Total assessment component weight (${totalMax} marks) exceeds the maximum allowed staff allocation of ${maxAllowedStaffAllocation} marks (5 marks reserved for attendance).`
      });
    }

    if (!is2021 && isPureLabSubmission && components.length === 0 && attendance && Array.isArray(attendance)) {
      for (const a of attendance) {
        const rawLab = a.labMark !== undefined && a.labMark !== null && a.labMark !== '' ? a.labMark : a.internalExamMark;
        if (rawLab !== undefined && rawLab !== null && rawLab !== '' && rawLab !== 'AB') {
          const v = parseFloat(rawLab);
          if (!isNaN(v) && v > 95) {
            await conn.rollback();
            return res.status(400).json({
              error: `Direct laboratory assessment mark (${v}) exceeds the maximum allowed assessment activities mark of 95 marks (5 marks reserved for attendance).`
            });
          }
        }
      }
    }

    // avg = (sum of converted marks) / studentCount
    const safeMarks = Array.isArray(marks) ? marks : [];
    const safeAttendance = Array.isArray(attendance) ? attendance : [];
    const studentIds = [...new Set([...safeMarks.map((m) => m.studentId), ...safeAttendance.map((a) => a.studentId)])];
    const studentCount = studentIds.length;

    // Anna Univ 25th Regulation attendance rule:
    // 95–100% → 5 marks, 90–95% → 3 marks, 85–90% → 2 marks, 80–85% → 1 mark, <80% → 0 marks
    const getAttendanceMark = (pct) => {
      if (pct >= 95) return 5;
      if (pct >= 90) return 3;
      if (pct >= 85) return 2;
      if (pct >= 80) return 1;
      return 0; // Below 80% is 0 mark
    };

    // Group marks by student to compute converted total per student
    const studentTotals = {};
    for (const m of safeMarks) {
      if (!studentTotals[m.studentId]) studentTotals[m.studentId] = 0;

      const comp = components[m.componentIndex];
      if (comp) {
        const conductedMax = parseFloat(comp.conductedMax) || 100;
        const weight = parseFloat(comp.maxMarks) || 0;
        const val = parseFloat(m.marksObtained) || 0;
        const converted = conductedMax > 0 ? (Math.min(val, conductedMax) / conductedMax) * weight : 0;
        studentTotals[m.studentId] += converted;
      }
    }

    if (attendance && Array.isArray(attendance)) {
      const tHours = parseInt(totalHours, 10) || 0;

      // Find max actual hours entered across the class
      let maxActualHours = 0;
      for (const a of attendance) {
        const raw = parseInt(a.actualTakenHours !== undefined && a.actualTakenHours !== '' ? a.actualTakenHours : (a.hoursAttended || 0), 10) || 0;
        if (raw > maxActualHours) maxActualHours = raw;
      }

      for (const a of attendance) {
        if (!studentTotals[a.studentId]) studentTotals[a.studentId] = 0;
        const rawHours = parseInt(a.actualTakenHours !== undefined && a.actualTakenHours !== '' ? a.actualTakenHours : (a.hoursAttended || 0), 10) || 0;
        const labHrs = parseInt(a.labAttendance, 10) || 0;
        let attMark = 0;

        if (a.attendanceMark !== undefined && a.attendanceMark !== null && !isNaN(parseFloat(a.attendanceMark))) {
          attMark = parseFloat(a.attendanceMark);
        } else if (sessionLabel === 'internal2') {
          const i1Attd = parseInt(a.int1AttendanceHours, 10) || 0;
          const cumAttd = i1Attd + rawHours + labHrs;
          const i1Max = parseInt(req.body.int1Hours, 10) || Math.ceil(tHours / 2) || 0;
          const i2Max = parseInt(req.body.int2Hours, 10) || Math.floor(tHours / 2) || 0;
          const lMax = parseInt(req.body.labHours, 10) || 0;
          const cumPrescribedMax = (i1Max + i2Max + lMax) || tHours || 0;
          const cumConductedBase = Math.max(cumPrescribedMax, maxActualHours > 0 ? maxActualHours + i1Max + lMax : cumPrescribedMax);

          const pct = cumConductedBase > 0 ? (cumAttd / cumConductedBase) * 100 : 0;
          attMark = getAttendanceMark(pct);
        } else {
          // If actual attended hours (e.g. 45) exceeds total prescribed hours (e.g. 30),
          // convert proportionally based on the conducted hours
          const conductedBase = Math.max(tHours, maxActualHours);
          const pct = conductedBase > 0 ? (rawHours / conductedBase) * 100 : 0;
          attMark = getAttendanceMark(pct);
        }
        // Continuous assessment includes attendance marks (up to 5m) for all 2025 courses (UG & PG)
        studentTotals[a.studentId] += attMark;
      }
    }

    let labAvgScore = 0;
    if (isPureLabSubmission && attendance && Array.isArray(attendance)) {
      let lSum = 0;
      let lCount = 0;
      attendance.forEach(a => {
        const v = parseFloat(a.labMark !== undefined && a.labMark !== null && a.labMark !== '' ? a.labMark : a.internalExamMark);
        if (!isNaN(v)) {
          if (!is2021) {
            // Regulation 2025 (UG & PG): direct lab assessment (max 95) + attendance mark (max 5) = total out of 100
            const attMark = parseFloat(a.attendanceMark) || (studentTotals[a.studentId] !== undefined ? studentTotals[a.studentId] : 0);
            const studentTotal = Math.min(100, Math.round(v) + attMark);
            lSum += studentTotal;
          } else {
            // Regulation 2021: direct lab exam mark out of 100
            lSum += v;
          }
          lCount++;
        }
      });
      labAvgScore = lCount > 0 ? (lSum / lCount) : 0;
    }
    const avgScore = isPureLabSubmission ? labAvgScore : ((Object.values(studentTotals).reduce((s, t) => s + t, 0) / (studentCount || 1)) || 0);

    // 2. Safe Session Upsert (never wipe or change sessionId if it already exists)
    const statusVal = actionType === 'frozen' ? 'locked' : (existingSession?.status === 'locked' ? 'locked' : 'draft');
    let sessionId;

    let existingExamDate = null;
    if (schema.hasExamDateCol) {
      existingExamDate = existingSession?.exam_date || null;
    } else if (existingSession?.id) {
      existingExamDate = await resolveExamDateFromSettings(conn, existingSession.id, subjectId, classId, sessionLabel);
    }

    let finalExamDate;
    if (examDate === undefined) {
      // Preserve existing exam date when omitted from payload
      finalExamDate = existingExamDate || null;
    } else if (!cleanExamDate) {
      // Explicitly cleared date
      finalExamDate = null;
    } else {
      finalExamDate = cleanExamDate;
    }

    if (existingSession) {
      sessionId = existingSession.id;
      const updateFields = ['staff_id = ?', 'total_max = ?'];
      const updateParams = [String(effectiveStaffId), totalMax];

      if (schema.hasTotalHoursCol) {
        updateFields.push('total_hours = ?');
        updateParams.push(parseInt(sessionTotalHours, 10) || 0);
      }
      if (schema.hasInternal2TotalHoursCol) {
        updateFields.push('internal2_total_hours = ?');
        updateParams.push(parseInt(internal2TotalHours, 10) || 0);
      }

      updateFields.push('status = ?', 'avg_score = ?', 'student_count = ?', 'remedial_action = ?');
      updateParams.push(statusVal, avgScore, studentCount, remedialAction || '');

      if (schema.hasExamDateCol) {
        updateFields.push('exam_date = ?');
        updateParams.push(finalExamDate);
      }

      updateFields.push('updated_at = NOW()');
      updateParams.push(sessionId);

      await conn.execute(
        `UPDATE marks_sessions SET ${updateFields.join(', ')} WHERE id = ?`,
        updateParams
      );
    } else {
      const insertCols = ['subject_id', 'class_id', 'staff_id'];
      const insertVals = [String(subjectId), String(classId), String(effectiveStaffId)];

      insertCols.push('session_label');
      insertVals.push(sessionLabel || 'Internal Assessment');

      if (schema.hasExamDateCol) {
        insertCols.push('exam_date');
        insertVals.push(finalExamDate);
      }

      insertCols.push('total_max');
      insertVals.push(totalMax);

      if (schema.hasTotalHoursCol) {
        insertCols.push('total_hours');
        insertVals.push(parseInt(sessionTotalHours, 10) || 0);
      }
      if (schema.hasInternal2TotalHoursCol) {
        insertCols.push('internal2_total_hours');
        insertVals.push(parseInt(internal2TotalHours, 10) || 0);
      }

      insertCols.push('status', 'avg_score', 'student_count', 'remedial_action');
      insertVals.push(statusVal, avgScore, studentCount, remedialAction || '');

      const placeholders = insertCols.map(() => '?').join(', ');
      const [sessionResult] = await conn.execute(
        `INSERT INTO marks_sessions (${insertCols.join(', ')}) VALUES (${placeholders})`,
        insertVals
      );
      sessionId = sessionResult.insertId;
    }

    // Persist or clear exam date in system_settings
    if (examDate !== undefined) {
      await saveExamDateToSettings(conn, sessionId, subjectId, classId, sessionLabel, finalExamDate);
    } else if (finalExamDate) {
      await saveExamDateToSettings(conn, sessionId, subjectId, classId, sessionLabel, finalExamDate);
    }

    // 3. Safe Component In-Place Update (keeps existing component IDs stable)
    const [existingComps] = await conn.execute(
      `SELECT id, type_id, sort_order FROM assessment_components WHERE session_id = ? ORDER BY sort_order`,
      [sessionId]
    );

    const componentIdMap = {}; // index → DB id
    for (let i = 0; i < components.length; i++) {
      const c = components[i];
      if (existingComps[i]) {
        const compId = existingComps[i].id;
        await conn.execute(
          `UPDATE assessment_components
           SET type_id = ?, label = ?, conducted_max = ?, max_marks = ?, icon = ?, color = ?, sort_order = ?
           WHERE id = ?`,
          [c.typeId || 'written_test', c.label || c.name || 'Component', parseFloat(c.conductedMax) || 100, parseFloat(c.maxMarks) || 0, c.icon || '', c.color || '', i, compId]
        );
        componentIdMap[i] = compId;
      } else {
        const [compResult] = await conn.execute(
          `INSERT INTO assessment_components
             (session_id, type_id, label, conducted_max, max_marks, icon, color, sort_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [sessionId, c.typeId || 'written_test', c.label || c.name || 'Component', parseFloat(c.conductedMax) || 100, parseFloat(c.maxMarks) || 0, c.icon || '', c.color || '', i]
        );
        componentIdMap[i] = compResult.insertId;
      }
    }

    // Clean up trailing components only if components array explicitly shrank
    if (existingComps.length > components.length) {
      for (let i = components.length; i < existingComps.length; i++) {
        await conn.execute(`DELETE FROM assessment_components WHERE id = ?`, [existingComps[i].id]);
      }
    }

    // Resolve staff name for audit trail
    let staffName = req.body.staffName || req.body.userName || '';
    if (!staffName && staffId) {
      try {
        const [stRows] = await conn.execute(`SELECT name FROM staffs WHERE id = ?`, [staffId]);
        if (stRows.length > 0) staffName = stRows[0].name;
      } catch (_) {}
    }

    // Fetch existing marks and attendance snapshots to calculate audit deltas
    const oldMarksMap = new Map();
    const oldAttMap = new Map();
    if (existingSession) {
      try {
        const [oldMarksRows] = await conn.execute(
          `SELECT student_id, component_id, marks_obtained FROM marks WHERE session_id = ?`,
          [sessionId]
        );
        oldMarksRows.forEach(r => {
          oldMarksMap.set(`${r.student_id}_${r.component_id}`, r.marks_obtained !== null && r.marks_obtained !== undefined ? parseFloat(r.marks_obtained) : null);
        });

        const [oldAttRows] = await conn.execute(
          `SELECT student_id, hours_attended, actual_taken_hours, attendance_mark, internal_exam_mark, lab_attendance, lab_mark FROM session_attendance WHERE session_id = ?`,
          [sessionId]
        );
        oldAttRows.forEach(r => {
          oldAttMap.set(String(r.student_id), r);
        });
      } catch (oldFetchErr) {
        console.warn('Old records snapshot notice:', oldFetchErr.message);
      }
    }

    const auditLogEntries = [];

    // 4. Safe Marks Upsert (ON DUPLICATE KEY UPDATE) with Audit Delta Logging
    for (const m of safeMarks) {
      const compDbId = componentIdMap[m.componentIndex];
      if (compDbId === undefined) continue;
      const sId = String(m.studentId);
      const key = `${sId}_${compDbId}`;
      const oldVal = oldMarksMap.has(key) ? oldMarksMap.get(key) : null;
      const hasNew = m.marksObtained !== null && m.marksObtained !== '' && m.marksObtained !== undefined && !isNaN(parseFloat(m.marksObtained));
      const newVal = hasNew ? parseFloat(m.marksObtained) : null;

      if (oldVal !== newVal) {
        auditLogEntries.push([
          sessionId,
          sId,
          compDbId,
          'marks_obtained',
          oldVal !== null ? String(oldVal) : null,
          newVal !== null ? String(newVal) : null,
          String(actingStaff.id),
          String(actingStaff.name || actingStaff.id),
          String(actionType || 'save')
        ]);
      }

      if (!hasNew) {
        await conn.execute(
          `DELETE FROM marks WHERE session_id = ? AND component_id = ? AND student_id = ?`,
          [sessionId, compDbId, sId]
        );
      } else {
        await conn.execute(
          `INSERT INTO marks (session_id, component_id, student_id, marks_obtained)
           VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained)`,
          [sessionId, compDbId, sId, newVal]
        );
      }
    }

    // 5. Insert Attendance & Internal Exam
    if (attendance && Array.isArray(attendance)) {
      const tHours = parseInt(totalHours, 10) || 30;

      for (const a of attendance) {
        const rawHours = parseInt(a.hoursAttended !== undefined && a.hoursAttended !== '' ? a.hoursAttended : (a.actualTakenHours || 0), 10) || 0;
        const labHrs = parseInt(a.labAttendance, 10) || 0;
        let attMark = 0;
        const savedHours = Math.max(0, rawHours);

        if (sessionLabel === 'internal2') {
          const i1Attd = parseInt(a.int1AttendanceHours, 10) || 0;
          const i1Max = parseInt(req.body.int1Hours, 10) || 30;
          const i2Max = parseInt(req.body.int2Hours, 10) || 30;
          const lMax = parseInt(req.body.labHours, 10) || 0;

          if (i1Attd > 0) {
            const cumPrescribedMax = (i1Max + i2Max) || tHours || 60;
            const cappedI2 = Math.min(i2Max, Math.max(0, rawHours));
            const cumAttd = Math.min(cumPrescribedMax, Math.min(i1Max, i1Attd) + cappedI2);

            const pct = cumPrescribedMax > 0 ? Math.min(100, Math.round((cumAttd / cumPrescribedMax) * 100)) : 0;
            attMark = getAttendanceMark(pct);
          } else {
            // When Internal 1 is not recorded / 0, calculate against Internal 2's prescribed hours
            const activeMax = i2Max || tHours || 30;
            const cappedI2 = Math.min(activeMax, Math.max(0, rawHours));
            const pct = activeMax > 0 ? Math.min(100, Math.round((cappedI2 / activeMax) * 100)) : 0;
            attMark = getAttendanceMark(pct);
          }
        } else {
          // Internal 1: Calculate attendance mark percentage
          const prescribedHours = parseInt(req.body.int1Hours, 10) || tHours || 30;
          const cappedHours = Math.min(prescribedHours, Math.max(0, rawHours));
          const pct = prescribedHours > 0 ? Math.min(100, Math.round((cappedHours / prescribedHours) * 100)) : 0;
          attMark = getAttendanceMark(pct);
        }

        // If client explicitly passed a calculated attendanceMark, use it as fallback
        if (a.attendanceMark !== undefined && a.attendanceMark !== null && !isNaN(parseFloat(a.attendanceMark)) && parseFloat(a.attendanceMark) > 0) {
          attMark = parseFloat(a.attendanceMark);
        }

        // Track attendance & exam audit deltas
        const sId = String(a.studentId);
        const oldRec = oldAttMap.get(sId);

        const oldAttMark = oldRec && oldRec.attendance_mark !== null && oldRec.attendance_mark !== undefined ? parseFloat(oldRec.attendance_mark) : null;
        const newAttMark = attMark !== null && attMark !== undefined ? parseFloat(attMark) : null;
        if (oldAttMark !== newAttMark) {
          auditLogEntries.push([
            sessionId,
            sId,
            null,
            'attendance_mark',
            oldAttMark !== null ? String(oldAttMark) : null,
            newAttMark !== null ? String(newAttMark) : null,
            String(actingStaff.id),
            String(actingStaff.name || actingStaff.id),
            String(actionType || 'save')
          ]);
        }

        const oldHours = oldRec && oldRec.hours_attended !== null && oldRec.hours_attended !== undefined ? parseInt(oldRec.hours_attended, 10) : null;
        const newHours = parseInt(savedHours, 10);
        if (oldHours !== newHours) {
          auditLogEntries.push([
            sessionId,
            sId,
            null,
            'hours_attended',
            oldHours !== null ? String(oldHours) : null,
            String(newHours),
            String(actingStaff.id),
            String(actingStaff.name || actingStaff.id),
            String(actionType || 'save')
          ]);
        }

        const oldExam = oldRec && oldRec.internal_exam_mark !== null && oldRec.internal_exam_mark !== undefined && oldRec.internal_exam_mark !== '' ? parseFloat(oldRec.internal_exam_mark) : null;
        const newExam = (a.internalExamMark !== undefined && a.internalExamMark !== null && a.internalExamMark !== '' && !isNaN(parseFloat(a.internalExamMark))) ? parseFloat(a.internalExamMark) : null;
        if (oldExam !== newExam) {
          auditLogEntries.push([
            sessionId,
            sId,
            null,
            'internal_exam_mark',
            oldExam !== null ? String(oldExam) : null,
            newExam !== null ? String(newExam) : null,
            String(actingStaff.id),
            String(actingStaff.name || actingStaff.id),
            String(actionType || 'save')
          ]);
        }

        const oldLab = oldRec && oldRec.lab_mark !== null && oldRec.lab_mark !== undefined && oldRec.lab_mark !== '' ? parseFloat(oldRec.lab_mark) : null;
        const newLab = (a.labMark !== undefined && a.labMark !== null && a.labMark !== '' && !isNaN(parseFloat(a.labMark))) ? parseFloat(a.labMark) : null;
        if (oldLab !== newLab) {
          auditLogEntries.push([
            sessionId,
            sId,
            null,
            'lab_mark',
            oldLab !== null ? String(oldLab) : null,
            newLab !== null ? String(newLab) : null,
            String(actingStaff.id),
            String(actingStaff.name || actingStaff.id),
            String(actionType || 'save')
          ]);
        }

        await conn.execute(
          `INSERT INTO session_attendance (session_id, student_id, hours_attended, actual_taken_hours, attendance_mark, internal_exam_mark, lab_attendance, lab_mark)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             hours_attended = VALUES(hours_attended),
             actual_taken_hours = VALUES(actual_taken_hours),
             attendance_mark = VALUES(attendance_mark),
             internal_exam_mark = VALUES(internal_exam_mark),
             lab_attendance = VALUES(lab_attendance),
             lab_mark = VALUES(lab_mark)`,
          [
            sessionId,
            String(a.studentId),
            savedHours,
            savedHours,
            attMark,
            (a.internalExamMark !== undefined && a.internalExamMark !== null && a.internalExamMark !== '' && !isNaN(parseFloat(a.internalExamMark)))
              ? parseFloat(a.internalExamMark)
              : (isPureLabSubmission && a.labMark !== undefined && a.labMark !== null && a.labMark !== '' && !isNaN(parseFloat(a.labMark)) ? parseFloat(a.labMark) : null),
            (a.labAttendance !== undefined && a.labAttendance !== null && a.labAttendance !== '' && !isNaN(parseInt(a.labAttendance, 10)))
              ? parseInt(a.labAttendance, 10)
              : (isPureLabSubmission ? savedHours : (labHrs > 0 ? labHrs : null)),
            (a.labMark !== undefined && a.labMark !== null && a.labMark !== '' && !isNaN(parseFloat(a.labMark)))
              ? parseFloat(a.labMark)
              : (isPureLabSubmission && a.internalExamMark !== undefined && a.internalExamMark !== null && a.internalExamMark !== '' && !isNaN(parseFloat(a.internalExamMark)) ? parseFloat(a.internalExamMark) : null)
          ]
        );
      }
    }

    // 5.4 Persist individual mark changes to marks_audit_logs
    if (auditLogEntries.length > 0) {
      try {
        for (const entry of auditLogEntries) {
          await conn.execute(
            `INSERT INTO marks_audit_logs
              (session_id, student_id, component_id, field_name, old_value, new_value, user_id, user_name, action_type)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            entry
          );
        }
      } catch (auditErr) {
        console.warn('marks_audit_logs insert note:', auditErr.message);
      }
    }

    // 5.5 Record safe audit snapshot in marks_history for recovery
    try {
      await conn.execute(
        `INSERT INTO marks_history (session_id, subject_id, class_id, session_label, staff_id, action_type, snapshot)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          sessionId,
          String(subjectId),
          String(classId),
          String(sessionLabel),
          String(actingStaff.id),
          actionType || 'save',
          JSON.stringify({
            studentCount,
            marksCount: safeMarks.length,
            avgScore,
            totalMax,
            savedAt: new Date().toISOString()
          })
        ]
      );
    } catch (histErr) {
      console.warn('marks_history audit log notice:', histErr.message);
    }

    await conn.commit();

    // 6. Notifications for Freeze action
    if (actionType === 'frozen') {
      try {
        let effClassId = classId;
        if (!effClassId && sessionId) {
          const [sessRows] = await db.execute('SELECT class_id FROM marks_sessions WHERE id = ?', [sessionId]);
          if (sessRows.length > 0 && sessRows[0].class_id) effClassId = sessRows[0].class_id;
        }

        const [subRows] = await db.execute(`
          SELECT s.code, s.name, s.department AS sub_dept, s.class_id,
                 c.department AS class_dept, c.year_label, c.name AS class_name, c.class_coordinator
          FROM subjects s
          LEFT JOIN classes c ON c.id = COALESCE(?, s.class_id)
          WHERE s.id = ?
        `, [effClassId || null, subjectId]);
        const sub = subRows.length > 0 ? subRows[0] : null;
        const subName = sub ? `${sub.code} ${sub.name}` : 'A Subject';
        let coordNotified = false;

        // Resolve true department: ALWAYS the class department
        const dept = resolveSubjectDepartment(sub);

        // Freezer staff name
        const freezerName = actingStaff.name || actingStaff.id;

        // Notify HOD of the CLASS department ONLY
        await db.execute(
          `INSERT INTO notifications (target_role, target_department, title, message, link) VALUES ('hod', ?, 'Marks Frozen', ?, '/dashboard')`,
          [dept, `Marks for ${subName} (${sub?.class_name || 'Class'}) have been frozen by ${freezerName}.`]
        );

        // Notify College Administration / Leadership
        await db.execute(
          `INSERT INTO notifications (target_role, title, message, link) VALUES ('admin', 'Subject Marks Finalized', ?, '/dashboard')`,
          [`Marks for ${subName} (${sub?.class_name || sessionLabel}) have been frozen and finalized by ${freezerName}.`]
        );

        // Notify Specific Class Coordinator
        if (sub && sub.class_id) {
          const [classRows] = await db.execute('SELECT name, department, class_coordinator FROM classes WHERE id = ?', [sub.class_id]);
          if (classRows.length > 0 && classRows[0].class_coordinator) {
            const coordStr = classRows[0].class_coordinator.trim();
            const cleanName = coordStr.split(/,|\s+(?:TF|AP|Prof|Dr|HoD)\//)[0].trim();
            const [coordStaffs] = await db.query(
              'SELECT id FROM staffs WHERE INSTR(?, name) > 0 OR INSTR(name, ?) > 0 LIMIT 1',
              [coordStr, cleanName]
            );
            if (coordStaffs.length > 0) {
              await db.execute(
                `INSERT INTO notifications (target_id, title, message, link) VALUES (?, 'Class Subject Marks Frozen', ?, '/reports')`,
                [coordStaffs[0].id, `Marks for ${subName} (${classRows[0].name}) have been frozen. You can now view the updated class performance.`]
              );
              coordNotified = true;
            }
          }
        }
        if (!coordNotified) {
          await db.execute(
            `INSERT INTO notifications (target_role, target_department, title, message, link) VALUES ('class_coordinator', ?, 'Class Subject Marks Frozen', ?, '/reports')`,
            [dept, `Marks for ${subName} (${sub?.class_name || 'Class'}) have been frozen. You can now view the updated class performance.`]
          );
        }
      } catch (notifErr) {
        console.error('Failed to send freeze notifications:', notifErr);
      }
    }

    res.json({ success: true, sessionId, avgScore, studentCount, examDate: finalExamDate });
  } catch (err) {
    await conn.rollback();
    console.error('POST /marks/submit error:', err);
    res.status(500).json({ error: 'Failed to save marks: ' + err.message });
  } finally {
    conn.release();
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/marks/sessions?classId=CL001&staffId=FAC001
// Returns all sessions with subject + staff info
// ─────────────────────────────────────────────────────────────
router.get('/sessions', async (req, res) => {
  try {
    const { classId, staffId, subjectId, sessionLabel, department } = req.query;
    let sql = `
      SELECT ms.id, ms.session_label, NULL AS exam_date, ms.total_max, ms.status,
             ms.avg_score, ms.student_count, ms.created_at, ms.subject_id, ms.class_id,
             sub.name AS subject, sub.code AS subject_code, sub.acronym, sub.department AS subject_department,
             cl.name  AS class_name, cl.department AS class_department, cl.year_label, cl.semester,
             st.name  AS staff_name, st.designation AS staff_designation
      FROM marks_sessions ms
      JOIN subjects sub ON sub.id = ms.subject_id
      JOIN classes  cl  ON cl.id  = ms.class_id
      LEFT JOIN staffs st ON st.id = ms.staff_id
    `;
    const params = [];
    const where = [];
    if (classId)      { where.push('ms.class_id = ?');   params.push(classId); }
    if (staffId) {
      const [aliasRows] = await db.query(
        `SELECT id FROM staffs WHERE id = ? OR email = (SELECT email FROM staffs WHERE id = ? LIMIT 1)`,
        [staffId, staffId]
      );
      const fStaffIds = Array.from(new Set([staffId, ...aliasRows.map(r => r.id)]));
      if (staffId === 'S_CHITRA' || staffId === 'FAC002') fStaffIds.push('S_CHITRA', 'FAC002');
      if (staffId === 'S_NAVEENKARTHICK' || staffId === 'FAC_IT_103') fStaffIds.push('S_NAVEENKARTHICK', 'FAC_IT_103');
      if (staffId === 'S_MAREESWARI' || staffId === 'FAC006') fStaffIds.push('S_MAREESWARI', 'FAC006');
      if (staffId === 'S_KARUNYA' || staffId === 'FAC010' || staffId === 'FAC026') fStaffIds.push('S_KARUNYA', 'FAC010', 'FAC026');
      if (staffId === 'S_RICHARD' || staffId === 'FAC017') fStaffIds.push('S_RICHARD', 'FAC017');
      if (staffId === 'S_KESAVA' || staffId === 'FAC005') fStaffIds.push('S_KESAVA', 'FAC005');
      if (staffId === 'S_UDHAYA' || staffId === 'FAC004') fStaffIds.push('S_UDHAYA', 'FAC004');
      if (staffId === 'S_BHAVANI' || staffId === 'FAC_IT_101') fStaffIds.push('S_BHAVANI', 'FAC_IT_101');
      if (staffId === 'S_VENNIMALAI' || staffId === 'FAC052') fStaffIds.push('S_VENNIMALAI', 'FAC052');
      if (staffId === 'S_RATHIMALA' || staffId === 'FAC016') fStaffIds.push('S_RATHIMALA', 'FAC016');
      if (staffId === 'S_JENIFER' || staffId === 'FAC021') fStaffIds.push('S_JENIFER', 'FAC021');

      const sPlaceholders = fStaffIds.map(() => '?').join(',');
      where.push(`ms.staff_id IN (${sPlaceholders})`);
      params.push(...fStaffIds);
    }
    if (subjectId)    { where.push('ms.subject_id = ?'); params.push(subjectId); }
    if (sessionLabel) { where.push('ms.session_label = ?'); params.push(sessionLabel); }
    if (department) {
      if (department === 'Science and Humanities' || department === 'First Year' || department.toLowerCase().includes('science')) {
        where.push(`(cl.department = 'Science and Humanities' OR cl.department = 'First Year' OR cl.year_label = 'I' OR sub.department = 'Science and Humanities')`);
      } else {
        where.push(`(cl.department LIKE ? OR sub.department LIKE ?)`);
        params.push(`%${department}%`, `%${department}%`);
      }
    }
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    sql += ' ORDER BY ms.created_at DESC';

    const [rows] = await db.execute(sql, params);

    // Populate authoritative exam dates from individual session keys in a single batch query
    if (rows.length > 0) {
      const sessionKeys = rows.map(r => `exam_date_${r.id}`);
      const placeholders = sessionKeys.map(() => '?').join(', ');
      const [dateRows] = await db.execute(
        `SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (${placeholders})`,
        sessionKeys
      );
      const dateMap = new Map();
      for (const dr of dateRows) {
        if (dr.setting_key && dr.setting_value) {
          dateMap.set(dr.setting_key, String(dr.setting_value).substring(0, 10));
        }
      }
      rows.forEach(r => {
        if (!r.exam_date) {
          r.exam_date = dateMap.get(`exam_date_${r.id}`) || null;
        }
      });
    }
    res.json(rows);
  } catch (err) {
    console.error('GET /marks/sessions error:', err);
    res.status(500).json({ error: 'Failed to fetch sessions.' });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/marks/sessions/:id
// Returns one session with its components and all student marks
// ─────────────────────────────────────────────────────────────
router.get('/sessions/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Session info
    const [sessions] = await db.execute(
      `SELECT ms.*, sub.name AS subject, sub.code, cl.name AS class_name,
              st.name AS staff_name, st.designation AS staff_designation, st.department AS staff_department
       FROM marks_sessions ms
       LEFT JOIN subjects sub ON sub.id = ms.subject_id
       LEFT JOIN classes  cl  ON cl.id  = ms.class_id
       LEFT JOIN staffs st ON st.id = ms.staff_id
       WHERE ms.id = ?`, [id]
    );
    if (!sessions.length) return res.status(404).json({ error: 'Session not found.' });

    // Populate exam_date from system_settings if null or undefined
    if (!sessions[0].exam_date) {
      sessions[0].exam_date = await resolveExamDateFromSettings(
        db,
        sessions[0].id,
        sessions[0].subject_id,
        sessions[0].class_id,
        sessions[0].session_label
      );
    }

    // Components
    const [components] = await db.execute(
      'SELECT * FROM assessment_components WHERE session_id = ? ORDER BY sort_order', [id]
    );

    // Marks joined with student info
    const [marks] = await db.execute(
      `SELECT m.student_id, m.component_id, m.marks_obtained,
              s.name AS student_name, s.roll_no, s.s_no
       FROM marks m
       JOIN students s ON s.id = m.student_id
       WHERE m.session_id = ?
       ORDER BY s.s_no, m.component_id`, [id]
    );

    // Attendance & Internal Exam
    const [attendanceRows] = await db.execute(
      'SELECT student_id, hours_attended, actual_taken_hours, attendance_mark, internal_exam_mark, lab_attendance, lab_mark FROM session_attendance WHERE session_id = ?', [id]
    );
    const attendance = {};
    const attendanceMarks = {};
    const internalExam = {};
    const labData = {};
    attendanceRows.forEach(r => {
      const rawHrs = r.actual_taken_hours !== null && r.actual_taken_hours !== undefined ? r.actual_taken_hours : r.hours_attended;
      attendance[r.student_id] = rawHrs;
      const rawHrsNum = parseInt(rawHrs || 0, 10);
      const dbMark = (r.attendance_mark !== null && r.attendance_mark !== undefined) ? parseFloat(r.attendance_mark) : null;
      if (dbMark !== null && dbMark > 0) {
        attendanceMarks[r.student_id] = dbMark;
      } else if (rawHrsNum > 0) {
        const isInt2 = String(sessions[0]?.session_label || '').toLowerCase().trim() === 'internal2';
        const sInt2Max = parseInt(sessions[0]?.int2_hours, 10) || parseInt(sessions[0]?.total_hours, 10) || 30;
        const sInt1Max = parseInt(sessions[0]?.int1_hours, 10) || parseInt(sessions[0]?.total_hours, 10) || 30;
        const sTargetMax = isInt2 ? sInt2Max : sInt1Max;
        const pct = sTargetMax > 0 ? Math.min(100, Math.round((rawHrsNum / sTargetMax) * 100)) : 0;
        attendanceMarks[r.student_id] = getAttendanceMark(pct);
      } else {
        attendanceMarks[r.student_id] = 0;
      }
      internalExam[r.student_id] = r.internal_exam_mark;
      labData[r.student_id] = {
        labAttendance: r.lab_attendance,
        labMark: r.lab_mark
      };
    });

    res.json({ session: sessions[0], components, marks, attendance, attendanceMarks, internalExam, labData });
  } catch (err) {
    console.error('GET /marks/sessions/:id error:', err);
    res.status(500).json({ error: 'Failed to fetch session details.' });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/marks/unlock-session
// Instant unlock for HOD/Admin (bypasses request queue)
// ─────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────
// POST /api/marks/reset-session
// Cleanly purges/resets all marks, attendance, and components for a session
// ─────────────────────────────────────────────────────────────
router.post('/reset-session', async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const { sessionId, classId, subjectId, sessionLabel } = req.body;
    let sIds = [];

    if (sessionId) {
      sIds.push(sessionId);
    }

    if (classId && subjectId) {
      const query = sessionLabel && sessionLabel !== 'all'
        ? 'SELECT id FROM marks_sessions WHERE class_id = ? AND subject_id = ? AND session_label = ?'
        : 'SELECT id FROM marks_sessions WHERE class_id = ? AND subject_id = ?';
      const params = sessionLabel && sessionLabel !== 'all'
        ? [classId, subjectId, sessionLabel]
        : [classId, subjectId];
      const [sess] = await conn.execute(query, params);
      for (const s of sess) {
        if (!sIds.includes(s.id)) sIds.push(s.id);
      }
    }

    // Guard: locked or frozen sessions can NEVER be purged by reset
    for (const id of sIds) {
      const [sessRows] = await conn.execute(`SELECT id, status FROM marks_sessions WHERE id = ?`, [id]);
      if (sessRows.length > 0 && (sessRows[0].status === 'locked' || sessRows[0].status === 'frozen')) {
        await conn.rollback();
        return res.status(403).json({ error: 'Cannot reset locked or frozen marks sessions. Unlock must be approved by HOD first.' });
      }
    }

    for (const id of sIds) {
      await conn.execute('DELETE FROM marks WHERE session_id = ?', [id]);
      await conn.execute('DELETE FROM session_attendance WHERE session_id = ?', [id]);
      await conn.execute('DELETE FROM mark_unlock_requests WHERE session_id = ?', [id]);
      await conn.execute('DELETE FROM assessment_components WHERE session_id = ?', [id]);
      await conn.execute('DELETE FROM marks_sessions WHERE id = ?', [id]);
    }

    await conn.commit();
    res.json({ success: true, message: `Marks session(s) completely reset and cleared (${sIds.length} sessions).` });
  } catch (err) {
    await conn.rollback();
    console.error('POST /marks/reset-session error:', err);
    res.status(500).json({ error: 'Failed to reset marks session: ' + err.message });
  } finally {
    conn.release();
  }
});

// ─────────────────────────────────────────────────────────────
// DELETE /api/marks/sessions/:id
// ─────────────────────────────────────────────────────────────
router.delete('/sessions/:id', async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const sId = req.params.id;
    const [sessRows] = await conn.execute(`SELECT id, status FROM marks_sessions WHERE id = ?`, [sId]);
    if (sessRows.length > 0 && (sessRows[0].status === 'locked' || sessRows[0].status === 'frozen')) {
      await conn.rollback();
      return res.status(403).json({ error: 'Cannot delete locked or frozen marks sessions. Unlock must be approved by HOD first.' });
    }
    await conn.execute('DELETE FROM marks WHERE session_id = ?', [sId]);
    await conn.execute('DELETE FROM session_attendance WHERE session_id = ?', [sId]);
    await conn.execute('DELETE FROM mark_unlock_requests WHERE session_id = ?', [sId]);
    await conn.execute('DELETE FROM assessment_components WHERE session_id = ?', [sId]);
    await conn.execute('DELETE FROM marks_sessions WHERE id = ?', [sId]);
    await conn.commit();
    res.json({ success: true, message: 'Session deleted successfully.' });
  } catch (err) {
    await conn.rollback();
    console.error('DELETE /marks/sessions/:id error:', err);
    res.status(500).json({ error: 'Failed to delete session: ' + err.message });
  } finally {
    conn.release();
  }
});

router.post('/unlock-session', async (req, res) => {
  const conn = await db.getConnection();
  try {
    const sessionId = req.body?.sessionId?.sessionId || req.body?.sessionId;
    if (!sessionId) {
      conn.release();
      return res.status(400).json({ error: 'Missing sessionId.' });
    }

    // Derive acting user identity strictly from verified server authentication context
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      conn.release();
      return res.status(401).json({ error: 'Authentication required to unlock session. Marks remain frozen.' });
    }

    await conn.beginTransaction();

    const [sessRows] = await conn.execute(
      `SELECT ms.id, ms.subject_id, ms.class_id, ms.status, s.code, s.name, s.department AS sub_dept, s.class_id AS sub_class_id
       FROM marks_sessions ms
       LEFT JOIN subjects s ON s.id = ms.subject_id
       WHERE ms.id = ?`,
      [sessionId]
    );
    if (sessRows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ error: 'Marks session not found.' });
    }
    const session = sessRows[0];
    const sessionClassId = session.class_id || session.sub_class_id;

    // Fetch class details if available
    let targetClass = null;
    if (sessionClassId) {
      const [clsRows] = await conn.execute(
        'SELECT id, name, department FROM classes WHERE id = ? LIMIT 1',
        [sessionClassId]
      );
      targetClass = clsRows[0] || null;
    }

    let authoritativeDept = getAuthoritativeSubjectDepartment({
      department: session.sub_dept,
      code: session.code,
      name: session.name
    }, targetClass);

    if (!authoritativeDept && session.subject_id) {
      const [subRows] = await conn.execute(
        'SELECT id, code, name, department, class_id FROM subjects WHERE id = ? FOR SHARE',
        [session.subject_id]
      );
      if (subRows.length > 0) {
        if (!targetClass && subRows[0].class_id) {
          const [clsRows] = await conn.execute(
            'SELECT id, name, department FROM classes WHERE id = ? LIMIT 1',
            [subRows[0].class_id]
          );
          targetClass = clsRows[0] || null;
        }
        authoritativeDept = getAuthoritativeSubjectDepartment(subRows[0], targetClass);
      }
    }

    if (!authoritativeDept) {
      await conn.rollback();
      return res.status(400).json({ error: 'Cannot unlock marks sheet: Subject does not have a valid department mapping. Marks remain frozen.' });
    }

    // Validate acting staff from database or privileged administrative registry
    let staff;
    try {
      staff = await resolveActingStaff(conn, authUser.id, authUser.pwf);
    } catch (authErr) {
      await conn.rollback();
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!staff) {
      await conn.rollback();
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry. Marks remain frozen.' });
    }
    const staffRole = (staff.role || '').toLowerCase();
    const staffDeptCanonical = canonicalizeDepartment(staff.department);

    const isPrivileged = staffRole === 'admin' || staffRole === 'principal' || staffRole === 'vice_principal';
    const isSubjectHod = staffRole === 'hod' && staffDeptCanonical === authoritativeDept;
    const isClassHod = staffRole === 'hod' && targetClass && isClassAuthorizedForHod(targetClass, staff.department);
    const isAuthorizedHod = isSubjectHod || isClassHod;

    if (!isPrivileged && !isAuthorizedHod) {
      await conn.rollback();
      return res.status(403).json({
        error: `Unauthorized: Only the HOD of ${authoritativeDept} or Admin can directly unlock this marks sheet. Your department is ${staff.department || 'unassigned'}. Marks remain frozen.`
      });
    }

    await conn.execute(`UPDATE marks_sessions SET status = 'draft', updated_at = NOW() WHERE id = ?`, [sessionId]);
    await conn.commit();
    res.json({ success: true, message: 'Sheet unlocked successfully.' });
  } catch (err) {
    await conn.rollback();
    if (err.status === 401) {
      return res.status(401).json({ error: err.message });
    }
    console.error('POST /marks/unlock-session error:', err);
    res.status(500).json({ error: 'Failed to unlock sheet: ' + err.message });
  } finally {
    conn.release();
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/marks/request-unlock
// Staff requests permission from Subject Department HOD to edit a locked sheet
// ─────────────────────────────────────────────────────────────
router.post('/request-unlock', async (req, res) => {
  try {
    const { sessionId, subjectId, classId, reason } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: 'Missing sessionId.' });
    }

    // Derive requesting staff identity strictly from verified authentication context
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      return res.status(401).json({ error: 'Authentication required to submit unlock request. Marks remain frozen.' });
    }

    let requestingStaff;
    try {
      requestingStaff = await resolveActingStaff(db, authUser.id, authUser.pwf);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!requestingStaff) {
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry. Marks remain frozen.' });
    }
    const requestingStaffId = requestingStaff.id;

    let effSubjectId = subjectId;
    let effClassId = classId;
    const [sessRows] = await db.execute('SELECT id, subject_id, class_id, status FROM marks_sessions WHERE id = ?', [sessionId]);
    if (sessRows.length === 0) {
      return res.status(404).json({ error: 'Marks session not found.' });
    }
    if (sessRows[0].class_id) effClassId = sessRows[0].class_id;
    if (sessRows[0].subject_id) effSubjectId = sessRows[0].subject_id;

    if (!effSubjectId) {
      return res.status(400).json({ error: 'Cannot submit unlock request: No subject is associated with this session. Marks remain frozen.' });
    }

    // 0. Guard against redundant or duplicate unlock requests
    if (sessRows[0].status === 'draft' || sessRows[0].status === 'unlocked') {
      return res.status(400).json({ error: 'This marks sheet is already unlocked and editable.' });
    }

    const [existingPending] = await db.execute(
      `SELECT id FROM mark_unlock_requests WHERE session_id = ? AND status = 'pending'`,
      [sessionId]
    );
    if (existingPending.length > 0 || sessRows[0].status === 'unlock_requested') {
      return res.status(400).json({ error: 'An unlock request for this marks sheet is already pending approval.' });
    }

    // 1. Retrieve the actual subject associated with the unlock request
    const [subRows] = await db.execute(
      `SELECT id, code, name, department, class_id FROM subjects WHERE id = ?`,
      [effSubjectId]
    );

    if (subRows.length === 0) {
      return res.status(404).json({ error: 'Subject associated with this marks sheet not found.' });
    }
    const subject = subRows[0];

    // Resolve class information for recording and department resolution fallback
    const [classRows] = await db.execute(
      `SELECT c.id, c.name, c.department, c.year_label
       FROM classes c
       WHERE c.id = ? OR c.id = ? LIMIT 1`,
      [effClassId || '', subject.class_id || '']
    );
    const targetClass = classRows[0] || null;
    const finalClassId = targetClass?.id || effClassId || subject.class_id || '';

    // 2. Identify authoritative department using existing subject mapping (department primary, class owning dept fallback, code prefix fallback)
    const authoritativeDept = getAuthoritativeSubjectDepartment(subject, targetClass);
    if (!authoritativeDept) {
      console.error(`[Unlock Request Failed]: Subject ${subject.code} ${subject.name} (ID: ${subject.id}) has missing or ambiguous department mapping.`);
      return res.status(400).json({
        error: `Cannot submit unlock request: Subject "${subject.code} ${subject.name}" does not have a valid department mapping. Marks remain frozen. Please contact administration.`
      });
    }

    // 3. Retrieve the authorized HOD for that subject department
    const hod = await getDepartmentHod(db, authoritativeDept);
    if (!hod) {
      console.error(`[Unlock Request Failed]: No active HOD assigned for subject department: ${authoritativeDept}.`);
      return res.status(400).json({
        error: `Cannot submit unlock request: No HOD is currently assigned for the ${authoritativeDept} department. Marks remain frozen. Please contact administration.`
      });
    }

    // Update marks_sessions status to unlock_requested
    await db.execute(
      `UPDATE marks_sessions SET status = 'unlock_requested' WHERE id = ?`,
      [sessionId]
    );

    // Insert into mark_unlock_requests with guaranteed class_id and verified requesting staff ID
    await db.execute(
      `INSERT INTO mark_unlock_requests (session_id, subject_id, class_id, staff_id, reason, status)
       VALUES (?, ?, ?, ?, ?, 'pending')`,
      [sessionId, effSubjectId, finalClassId, requestingStaffId, reason || 'Requesting edit permission for marks sheet']
    );

    // Get verified staff details for notification
    const staffName = requestingStaff.name || authUser.name || 'A staff member';
    const staffDept = requestingStaff.department ? ` (${requestingStaff.department})` : '';
    const subjectTitle = `${subject.code} ${subject.name}`;

    // 4. Assign unlock request to that subject department's HOD via targeted notification
    await db.execute(
      `INSERT INTO notifications (target_role, target_department, target_id, title, message, link)
       VALUES ('hod', ?, ?, 'Marks Unlock Request', ?, '/dashboard#unlocks')`,
      [
        authoritativeDept,
        hod.id,
        `${staffName}${staffDept} requested to unlock marks for ${subjectTitle} (${authoritativeDept}).`
      ]
    );

    res.json({
      success: true,
      message: `Unlock request submitted to ${authoritativeDept} HOD (${hod.name}) successfully.`,
      targetDepartment: authoritativeDept,
      hodName: hod.name
    });
  } catch (err) {
    if (err.status === 401) {
      return res.status(401).json({ error: err.message });
    }
    console.error('POST /marks/request-unlock error:', err);
    res.status(500).json({ error: 'Failed to submit unlock request: ' + err.message });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/marks/unlock-requests
// Returns pending unlock requests routed to the SUBJECT department HOD
// ─────────────────────────────────────────────────────────────
router.get('/unlock-requests', async (req, res) => {
  try {
    // Derive acting user identity strictly from verified authentication context
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      return res.status(401).json({ error: 'Authentication required to view unlock requests.' });
    }

    // Validate acting staff from database or privileged administrative registry
    let staff;
    try {
      staff = await resolveActingStaff(db, authUser.id, authUser.pwf);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!staff) {
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry.' });
    }
    const staffRole = (staff.role || '').toLowerCase();
    const isPrivileged = staffRole === 'admin' || staffRole === 'principal' || staffRole === 'vice_principal';
    const isHod = staffRole === 'hod';

    if (!isPrivileged && !isHod) {
      return res.status(403).json({ error: 'Unauthorized: Regular faculty are not authorized to view pending unlock requests.' });
    }

    let sql = `
      SELECT ur.id, ur.session_id, ur.subject_id, ur.class_id, ur.staff_id,
             ur.reason, ur.status, ur.requested_at,
             COALESCE(st.name, ur.staff_id) AS staff_name,
             st.department AS staff_department,
             COALESCE(sub.name, ms.session_label, 'Subject') AS subject_name,
             sub.code AS subject_code,
             sub.department AS raw_subject_department,
             COALESCE(cl.name, 'Class') AS class_name,
             cl.department AS class_department,
             cl.year_label AS class_year,
             cl.semester AS class_semester,
             cl.batch AS class_batch,
             sub.semester AS subject_semester,
             ms.session_label,
             ms.status AS session_status
      FROM mark_unlock_requests ur
      LEFT JOIN marks_sessions ms ON ms.id = ur.session_id
      LEFT JOIN staffs st ON (st.id = ur.staff_id OR LOWER(st.email) = LOWER(ur.staff_id))
      LEFT JOIN subjects sub ON (sub.id = ur.subject_id OR sub.id = ms.subject_id)
      LEFT JOIN classes cl ON cl.id = COALESCE(NULLIF(ur.class_id, ''), ms.class_id, sub.class_id)
      WHERE ur.status = 'pending'
      ORDER BY ur.requested_at DESC
    `;

    const [rows] = await db.execute(sql);

    // Enrich each request with authoritative subject department and regulation
    const enriched = rows.map(r => {
      const targetClass = {
        id: r.class_id,
        name: r.class_name,
        department: r.class_department,
        batch: r.class_batch
      };
      const authDept = getAuthoritativeSubjectDepartment({
        department: r.raw_subject_department,
        code: r.subject_code,
        name: r.subject_name
      }, targetClass);
      const isPG = isPGClassEntity(targetClass) || isPGSubjectEntity({ id: r.subject_id, code: r.subject_code, name: r.subject_name }, targetClass);
      const resolvedReg = resolveAuthoritativeRegulation({
        classObj: targetClass,
        subject: { id: r.subject_id, code: r.subject_code, name: r.subject_name },
        isPG
      });
      const regulation = resolvedReg || 'UNRESOLVED';
      return {
        ...r,
        subject_department: authDept || r.raw_subject_department || 'Unassigned',
        regulation
      };
    });

    // If acting user is an HOD:
    // Derive department strictly from the authenticated staff record.
    // Client-supplied query parameter 'department' is NEVER trusted for HODs.
    if (isHod) {
      const hodDeptCanonical = canonicalizeDepartment(staff.department);
      if (!hodDeptCanonical) {
        return res.json([]);
      }
      const filtered = enriched.filter(r => {
        const reqDeptCanonical = canonicalizeDepartment(r.subject_department);
        if (reqDeptCanonical === hodDeptCanonical) return true;
        const targetClass = { id: r.class_id, name: r.class_name, department: r.class_department };
        return isClassAuthorizedForHod(targetClass, staff.department);
      });
      return res.json(filtered);
    }

    // If acting user is Admin / Principal / Vice Principal:
    // College-wide access is permitted. If an optional department filter is specified, apply it.
    const { department } = req.query;
    if (department && department.trim() && department.trim().toLowerCase() !== 'all') {
      const targetCanonical = canonicalizeDepartment(department.trim());
      const filtered = enriched.filter(r => {
        if (!targetCanonical) return false;
        return canonicalizeDepartment(r.subject_department) === targetCanonical;
      });
      return res.json(filtered);
    }

    res.json(enriched);
  } catch (err) {
    if (err.status === 401) {
      return res.status(401).json({ error: err.message });
    }
    console.warn('GET /marks/unlock-requests error:', err.message);
    res.status(500).json({ error: 'Failed to fetch unlock requests: ' + err.message });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/marks/approve-unlock
// Subject department HOD approves or rejects unlock request
// ─────────────────────────────────────────────────────────────
router.post('/approve-unlock', async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { requestId, sessionId, action } = req.body; // action = 'approve' | 'reject'
    if (!requestId || !sessionId || !action) {
      conn.release();
      return res.status(400).json({ error: 'Missing required parameters.' });
    }

    if (action !== 'approve' && action !== 'reject') {
      conn.release();
      return res.status(400).json({ error: 'Invalid action. Must be "approve" or "reject".' });
    }

    // Derive acting user identity strictly from verified server authentication context
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      conn.release();
      return res.status(401).json({ error: 'Authentication required to approve or reject unlock requests. Marks remain frozen.' });
    }

    await conn.beginTransaction();

    // 1. Fetch unlock request metadata (snapshot read, no lock)
    const [reqRows] = await conn.execute(
      `SELECT ur.id, ur.session_id, ur.subject_id, ur.class_id, ur.staff_id, ur.status,
              sub.code AS subject_code, sub.name AS subject_name, sub.department AS sub_dept,
              COALESCE(cl.name, 'Class') AS class_name, cl.department AS class_department,
              ms.status AS session_status
       FROM mark_unlock_requests ur
       LEFT JOIN subjects sub ON sub.id = ur.subject_id
       LEFT JOIN marks_sessions ms ON ms.id = ur.session_id
       LEFT JOIN classes cl ON cl.id = COALESCE(NULLIF(ur.class_id, ''), ms.class_id, sub.class_id)
       WHERE ur.id = ?`,
      [requestId]
    );

    if (reqRows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ error: 'Unlock request not found.' });
    }
    const reqData = reqRows[0];

    if (reqData.status !== 'pending') {
      await conn.rollback();
      return res.status(400).json({ error: `This unlock request has already been ${reqData.status}.` });
    }

    const targetClass = {
      id: reqData.class_id,
      name: reqData.class_name,
      department: reqData.class_department
    };

    // 2. Identify authoritative subject department
    const authoritativeDept = getAuthoritativeSubjectDepartment({
      department: reqData.sub_dept,
      code: reqData.subject_code,
      name: reqData.subject_name
    }, targetClass);

    if (!authoritativeDept) {
      await conn.rollback();
      return res.status(400).json({
        error: 'Cannot process unlock request: Subject does not have a valid department mapping. Marks remain frozen.'
      });
    }

    // 3. Validate acting staff from database or privileged administrative registry
    let staff;
    try {
      staff = await resolveActingStaff(conn, authUser.id, authUser.pwf);
    } catch (authErr) {
      await conn.rollback();
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!staff) {
      await conn.rollback();
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry. Marks remain frozen.' });
    }
    const staffRole = (staff.role || '').toLowerCase();
    const staffDeptCanonical = canonicalizeDepartment(staff.department);

    const isPrivileged = staffRole === 'admin' || staffRole === 'principal' || staffRole === 'vice_principal';
    const isSubjectHod = staffRole === 'hod' && staffDeptCanonical === authoritativeDept;
    const isClassHod = staffRole === 'hod' && targetClass && isClassAuthorizedForHod(targetClass, staff.department);
    const isAuthorizedHod = isSubjectHod || isClassHod;

    if (!isPrivileged && !isAuthorizedHod) {
      await conn.rollback();
      return res.status(403).json({
        error: `Unauthorized: Only the HOD of ${authoritativeDept} or Admin can ${action} this unlock request. Your department is ${staff.department || 'unassigned'}. Marks remain frozen.`
      });
    }

    // 4. Acquire exclusive lock on mark_unlock_requests row (downstream of marks_sessions)
    const [lockedReqRows] = await conn.execute(
      'SELECT id, status FROM mark_unlock_requests WHERE id = ? FOR UPDATE',
      [requestId]
    );
    if (lockedReqRows.length === 0 || lockedReqRows[0].status !== 'pending') {
      await conn.rollback();
      return res.status(400).json({ error: 'This unlock request is no longer pending.' });
    }

    const newSessionStatus = action === 'approve' ? 'unlocked' : 'locked';
    const newRequestStatus = action === 'approve' ? 'approved' : 'rejected';

    await conn.execute(
      `UPDATE marks_sessions SET status = ?, updated_at = NOW() WHERE id = ?`,
      [newSessionStatus, sessionId]
    );

    await conn.execute(
      `UPDATE mark_unlock_requests
       SET status = ?, actioned_at = CURRENT_TIMESTAMP, actioned_by = ?
       WHERE id = ?`,
      [newRequestStatus, staff.id, requestId]
    );

    await conn.commit();

    // Notify requesting faculty member directly (outside transaction)
    try {
      if (reqData.staff_id) {
        const subTitle = reqData.subject_code ? `${reqData.subject_code} ${reqData.subject_name || ''}` : 'the subject';
        const actionTitle = action === 'approve' ? 'Marks Unlock Approved' : 'Marks Unlock Declined';
        const actorLabel = isPrivileged ? 'College Administration' : `${authoritativeDept} HOD`;
        const actionMsg = action === 'approve'
          ? `Your request to edit marks for ${subTitle} was approved by ${actorLabel} (${staff.name}). You may now modify and re-freeze the marks sheet.`
          : `Your request to edit marks for ${subTitle} was declined by ${actorLabel} (${staff.name}).`;
        const actionLink = action === 'approve' ? `/marks-entry?classId=${reqData.class_id || ''}` : '/reports';

        await db.execute(
          `INSERT INTO notifications (target_id, title, message, link) VALUES (?, ?, ?, ?)`,
          [reqData.staff_id, actionTitle, actionMsg, actionLink]
        );
      }
    } catch (notifErr) {
      console.error('Failed to notify staff on unlock decision:', notifErr);
    }

    res.json({ success: true, message: `Request ${action}d successfully by ${staff.name}.` });
  } catch (err) {
    await conn.rollback();
    if (err.status === 401) {
      return res.status(401).json({ error: err.message });
    }
    console.error('POST /marks/approve-unlock error:', err);
    res.status(500).json({ error: 'Failed to process unlock action: ' + err.message });
  } finally {
    conn.release();
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/marks/class-summary?classId=CL001&sessionLabel=internal1
// Consolidated class data for Class Coordinator & Reports
// ─────────────────────────────────────────────────────────────
router.get('/class-summary', async (req, res) => {
  try {
    const { classId, sessionLabel = 'internal1' } = req.query;
    if (!classId) return res.status(400).json({ error: 'Missing classId' });

    // Class info
    const [clsRows] = await db.execute('SELECT * FROM classes WHERE id = ?', [classId]);
    if (!clsRows.length) return res.status(404).json({ error: 'Class not found' });
    const classObj = clsRows[0];

    // Subjects in class
    const [subjects] = await db.execute(
      `SELECT s.*, st.name AS staff_name
       FROM subjects s
       LEFT JOIN staffs st ON st.id = s.faculty_id
       WHERE s.class_id = ?
       ORDER BY s.code`,
      [classId]
    );

    // Merge system_settings subject_allocations configured from Admin Panel
    try {
      const [settingRows] = await db.execute("SELECT setting_value FROM system_settings WHERE setting_key = 'subject_allocations'");
      if (settingRows.length > 0 && settingRows[0].setting_value) {
        const allocs = typeof settingRows[0].setting_value === 'string'
          ? JSON.parse(settingRows[0].setting_value)
          : settingRows[0].setting_value;
        if (allocs && typeof allocs === 'object') {
          for (const sub of subjects) {
            const cleanId = String(sub.id || '').replace(/[\s\-]+/g, '');
            const cleanCode = String(sub.code || '').replace(/[\s\-]+/g, '');
            const classKey = `${sub.code}_${classId}`;
            const cleanClassKey = `${cleanCode}_${classId}`;
            const idClassKey = `${sub.id}_${classId}`;
            const a = allocs[classKey] || allocs[cleanClassKey] || allocs[idClassKey] ||
                      allocs[sub.id] || allocs[cleanId] || allocs[sub.code] || allocs[cleanCode] ||
                      Object.values(allocs).find(x => x && (x.id === sub.id || (x.code === sub.code && (!x.class_id || x.class_id === classId))));
            if (a) {
              const a1 = (a.int1_hours !== undefined && a.int1_hours !== null && a.int1_hours !== '') ? a.int1_hours : a.int1;
              const a2 = (a.int2_hours !== undefined && a.int2_hours !== null && a.int2_hours !== '') ? a.int2_hours : a.int2;
              const alb = (a.lab_hours !== undefined && a.lab_hours !== null && a.lab_hours !== '') ? a.lab_hours : a.lab;
              const atot = (a.total_hours !== undefined && a.total_hours !== null && a.total_hours !== '') ? a.total_hours : a.total;

              if (a1 !== undefined && a1 !== null && a1 !== '') sub.int1_hours = parseInt(a1, 10);
              if (a2 !== undefined && a2 !== null && a2 !== '') sub.int2_hours = parseInt(a2, 10);
              if (alb !== undefined && alb !== null && alb !== '') sub.lab_hours = parseInt(alb, 10);
              if (atot !== undefined && atot !== null && atot !== '') sub.total_hours = parseInt(atot, 10);
            }
          }
        }
      }
    } catch (allocErr) {
      console.warn('Note: subject_allocations merge notice in class-summary:', allocErr.message);
    }

    // Students in class
    const [students] = await db.execute(
      'SELECT id, s_no, roll_no, name FROM students WHERE class_id = ? ORDER BY s_no',
      [classId]
    );

    // Sessions for this class and sessionLabel
    const [sessions] = await db.execute(
      'SELECT * FROM marks_sessions WHERE class_id = ? AND session_label = ?',
      [classId, sessionLabel]
    );

    const sessionIds = sessions.map(s => s.id);
    let allAttendance = [];
    let allComponents = [];
    let allMarks = [];

    if (sessionIds.length > 0) {
      const placeholders = sessionIds.map(() => '?').join(',');
      const [att] = await db.execute(
        `SELECT * FROM session_attendance WHERE session_id IN (${placeholders})`,
        sessionIds
      );
      allAttendance = att;

      const [comps] = await db.execute(
        `SELECT * FROM assessment_components WHERE session_id IN (${placeholders})`,
        sessionIds
      );
      allComponents = comps;

      const [mks] = await db.execute(
        `SELECT * FROM marks WHERE session_id IN (${placeholders})`,
        sessionIds
      );
      allMarks = mks;
    }

    res.json({
      classObj,
      subjects,
      students,
      sessions,
      allAttendance,
      allComponents,
      allMarks
    });
  } catch (err) {
    console.error('GET /marks/class-summary error:', err);
    res.status(500).json({ error: 'Failed to fetch class summary.' });
  }
});




// ─────────────────────────────────────────────────────────────
// GET /api/marks/audit-logs/:sessionId
// Audit logs showing historical mark changes (old value, new value, user, timestamp)
// ─────────────────────────────────────────────────────────────
router.get('/audit-logs/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { studentId } = req.query;
    let sql = `
      SELECT al.id, al.session_id, al.student_id, al.component_id, al.field_name,
             al.old_value, al.new_value, al.user_id, al.user_name, al.action_type, al.created_at,
             s.name AS student_name, s.roll_no,
             ac.label AS component_label
      FROM marks_audit_logs al
      LEFT JOIN students s ON s.id = al.student_id
      LEFT JOIN assessment_components ac ON ac.id = al.component_id
      WHERE al.session_id = ?
    `;
    const params = [sessionId];
    if (studentId) {
      sql += ' AND al.student_id = ?';
      params.push(studentId);
    }
    sql += ' ORDER BY al.created_at DESC, al.id DESC';
    const [rows] = await db.execute(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('GET /marks/audit-logs error:', err);
    res.status(500).json({ error: 'Failed to fetch audit logs.' });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/marks/admin/subject-freeze-status
// List all subjects with their current marks freeze / unlock status
// Supports filtering by department, regulation (2021/2025), semester, class, and assessment session
// ─────────────────────────────────────────────────────────────
router.get('/admin/subject-freeze-status', async (req, res) => {
  try {
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    let staff;
    try {
      staff = await resolveActingStaff(db, authUser.id, authUser.pwf);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!staff) {
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry.' });
    }

    const staffRole = (staff.role || '').toLowerCase();
    const isPrivileged = staffRole === 'admin' || staffRole === 'principal' || staffRole === 'vice_principal';
    if (!isPrivileged) {
      return res.status(403).json({ error: 'Access denied: Administrative privileges required to manage subject freeze status.' });
    }

    const sessionLabel = (req.query.sessionLabel || 'internal1').trim();
    const { department, regulation, semester, classId, search } = req.query;

    const sql = `
      SELECT s.id AS subject_id,
             s.code AS subject_code,
             s.name AS subject_name,
             s.department AS raw_subject_department,
             s.semester AS subject_semester,
             s.class_id,
             c.name AS class_name,
             c.department AS class_department,
             c.year_label AS class_year,
             c.semester AS class_semester,
             c.batch AS class_batch,
             ms.id AS session_id,
             ms.session_label,
             ms.status AS session_status,
             ms.total_hours,
             ms.updated_at AS session_updated_at,
             ms.staff_id,
             st.name AS staff_name
      FROM subjects s
      JOIN classes c ON c.id = s.class_id
      LEFT JOIN marks_sessions ms ON ms.subject_id = s.id AND ms.session_label = ?
      LEFT JOIN staffs st ON st.id = ms.staff_id
      ORDER BY c.year_label ASC, c.name ASC, s.code ASC
    `;

    const [rows] = await db.execute(sql, [sessionLabel]);

    const enriched = rows.map(r => {
      const targetClass = {
        id: r.class_id,
        name: r.class_name,
        department: r.class_department,
        batch: r.class_batch
      };
      const authDept = getAuthoritativeSubjectDepartment({
        department: r.raw_subject_department,
        code: r.subject_code,
        name: r.subject_name
      }, targetClass);
      const isPG = isPGClassEntity(targetClass) || isPGSubjectEntity({ id: r.id, code: r.code, name: r.name }, targetClass);
      const resolvedReg = resolveAuthoritativeRegulation({
        classObj: targetClass,
        subject: { id: r.id, code: r.code, name: r.name },
        isPG
      });
      const reg = resolvedReg || 'UNRESOLVED';
      const status = r.session_status || 'not_started';
      const isFrozen = status === 'locked' || status === 'frozen';
      return {
        ...r,
        subject_department: authDept || r.raw_subject_department || 'Unassigned',
        regulation: reg,
        status,
        is_frozen: isFrozen,
        is_unlocked: !isFrozen
      };
    });

    let filtered = enriched;

    if (department && department !== 'all') {
      const d = department.toLowerCase().trim();
      filtered = filtered.filter(item => {
        const subDept = (item.subject_department || '').toLowerCase();
        const classDept = (item.class_department || '').toLowerCase();
        return subDept.includes(d) || classDept.includes(d);
      });
    }

    if (regulation && regulation !== 'all') {
      filtered = filtered.filter(item => item.regulation === regulation);
    }

    if (semester && semester !== 'all') {
      const semNum = parseInt(semester, 10);
      filtered = filtered.filter(item => {
        const cSem = parseInt(item.class_semester, 10);
        const sSem = parseInt(item.subject_semester, 10);
        return cSem === semNum || sSem === semNum;
      });
    }

    if (classId && classId !== 'all') {
      filtered = filtered.filter(item => String(item.class_id) === String(classId));
    }

    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(item => {
        const code = (item.subject_code || '').toLowerCase();
        const name = (item.subject_name || '').toLowerCase();
        const cName = (item.class_name || '').toLowerCase();
        const sName = (item.staff_name || '').toLowerCase();
        return code.includes(q) || name.includes(q) || cName.includes(q) || sName.includes(q);
      });
    }

    res.json(filtered);
  } catch (err) {
    if (err.status === 401) return res.status(401).json({ error: err.message });
    console.error('GET /marks/admin/subject-freeze-status error:', err);
    res.status(500).json({ error: 'Failed to fetch subject freeze status: ' + err.message });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/marks/admin/toggle-freeze
// Direct Admin Freeze or Unlock of a subject's marks session without requiring a faculty request
// Records state transition immediately in marks_audit_logs and sends targeted notifications
// ─────────────────────────────────────────────────────────────
router.post('/admin/toggle-freeze', async (req, res) => {
  const conn = await db.getConnection();
  try {
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    let staff;
    try {
      staff = await resolveActingStaff(db, authUser.id, authUser.pwf);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!staff) {
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry.' });
    }

    const staffRole = (staff.role || '').toLowerCase();
    const isPrivileged = staffRole === 'admin' || staffRole === 'principal' || staffRole === 'vice_principal';
    if (!isPrivileged) {
      return res.status(403).json({ error: 'Unauthorized: Administrative privileges required to directly freeze or unlock subjects.' });
    }

    const { subjectId, sessionLabel = 'internal1', action, reason } = req.body;
    if (!subjectId) {
      return res.status(400).json({ error: 'Missing subjectId.' });
    }
    if (action !== 'freeze' && action !== 'unlock') {
      return res.status(400).json({ error: "Invalid action. Must be 'freeze' or 'unlock'." });
    }

    await conn.beginTransaction();

    // 1. Fetch Subject & Class
    const [subRows] = await conn.execute(
      `SELECT s.id, s.code, s.name, s.department AS raw_subject_department, s.class_id, s.faculty_id,
              c.name AS class_name, c.department AS class_department
       FROM subjects s
       JOIN classes c ON c.id = s.class_id
       WHERE s.id = ?`,
      [subjectId]
    );

    if (subRows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ error: 'Subject not found.' });
    }

    const subject = subRows[0];
    const targetClass = {
      id: subject.class_id,
      name: subject.class_name,
      department: subject.class_department
    };
    const authoritativeDept = getAuthoritativeSubjectDepartment({
      department: subject.raw_subject_department,
      code: subject.code,
      name: subject.name
    }, targetClass) || subject.raw_subject_department || 'General';

    // Resolve valid staff ID for foreign key constraint (subjects.faculty_id or staffs table record)
    let targetStaffId = null;
    if (subject.faculty_id) {
      const [fRows] = await conn.execute(`SELECT id FROM staffs WHERE id = ?`, [subject.faculty_id]);
      if (fRows.length > 0) targetStaffId = fRows[0].id;
    }
    if (!targetStaffId) {
      const [sRows] = await conn.execute(`SELECT id FROM staffs WHERE id = ?`, [staff.id]);
      if (sRows.length > 0) {
        targetStaffId = sRows[0].id;
      } else {
        targetStaffId = 'ADM001';
      }
    }

    // 2. Check if marks_session already exists
    const [sessRows] = await conn.execute(
      `SELECT id, status, staff_id FROM marks_sessions WHERE subject_id = ? AND session_label = ?`,
      [subjectId, sessionLabel]
    );

    let sessionId;
    let oldStatus = 'not_started';
    const newStatus = action === 'freeze' ? 'locked' : 'unlocked';

    const schema = await getSchemaCapabilities(conn);

    if (sessRows.length > 0) {
      sessionId = sessRows[0].id;
      oldStatus = sessRows[0].status;

      await conn.execute(
        `UPDATE marks_sessions SET status = ?, updated_at = NOW() WHERE id = ?`,
        [newStatus, sessionId]
      );

      // Handle any active unlock requests for this session
      if (action === 'freeze') {
        await conn.execute(
          `UPDATE mark_unlock_requests SET status = 'rejected' WHERE session_id = ? AND status = 'pending'`,
          [sessionId]
        );
      } else if (action === 'unlock') {
        await conn.execute(
          `UPDATE mark_unlock_requests SET status = 'approved' WHERE session_id = ? AND status = 'pending'`,
          [sessionId]
        );
      }
    } else {
      // Create session row directly
      const insertCols = ['subject_id', 'class_id', 'staff_id'];
      const insertVals = [subject.id, subject.class_id, targetStaffId];

      insertCols.push('session_label', 'status');
      insertVals.push(sessionLabel, newStatus);

      if (schema.hasTotalHoursCol) {
        insertCols.push('total_hours');
        insertVals.push(30);
      }

      const placeholders = insertCols.map(() => '?').join(', ');
      const [insertRes] = await conn.execute(
        `INSERT INTO marks_sessions (${insertCols.join(', ')}) VALUES (${placeholders})`,
        insertVals
      );
      sessionId = insertRes.insertId;
    }

    // 3. Record in marks_audit_logs
    try {
      await conn.execute(
        `INSERT INTO marks_audit_logs
           (session_id, student_id, component_id, field_name, old_value, new_value, user_id, user_name, action_type)
         VALUES (?, 'ALL', NULL, 'status', ?, ?, ?, ?, ?)`,
        [
          sessionId,
          oldStatus,
          newStatus,
          staff.id,
          staff.name || 'College Administration',
          action === 'freeze' ? 'DIRECT_ADMIN_FREEZE' : 'DIRECT_ADMIN_UNLOCK'
        ]
      );
    } catch (auditErr) {
      console.warn('marks_audit_logs insert note:', auditErr.message);
    }

    // 4. Send Targeted Notifications
    try {
      const actorName = staff.name ? `${staff.name} (Administration)` : 'College Administration';
      const actionText = action === 'freeze' ? 'directly frozen and locked' : 'directly unlocked for editing';
      const notifMsg = `Marks for ${subject.code} ${subject.name} (${sessionLabel}) have been ${actionText} by ${actorName}.`;

      // Notify Subject Department HOD
      await conn.execute(
        `INSERT INTO notifications (target_role, target_department, title, message, link)
         VALUES ('hod', ?, ?, ?, '/dashboard')`,
        [
          authoritativeDept,
          action === 'freeze' ? 'Subject Marks Frozen by Admin' : 'Subject Marks Unlocked by Admin',
          notifMsg
        ]
      );

      // Notify Class Coordinator
      await conn.execute(
        `INSERT INTO notifications (target_role, target_department, title, message, link)
         VALUES ('class_coordinator', ?, ?, ?, '/reports')`,
        [
          subject.class_department || authoritativeDept,
          action === 'freeze' ? 'Class Subject Frozen' : 'Class Subject Unlocked',
          notifMsg
        ]
      );
    } catch (notifErr) {
      console.warn('Notification insert note:', notifErr.message);
    }

    await conn.commit();

    res.json({
      success: true,
      message: `Subject ${subject.code} ${subject.name} (${sessionLabel}) has been ${action === 'freeze' ? 'frozen and locked' : 'unlocked for editing'} successfully.`,
      sessionId,
      status: newStatus,
      is_frozen: newStatus === 'locked'
    });
  } catch (err) {
    await conn.rollback();
    if (err.status === 401) return res.status(401).json({ error: err.message });
    console.error('POST /marks/admin/toggle-freeze error:', err);
    res.status(500).json({ error: 'Failed to toggle subject freeze status: ' + err.message });
  } finally {
    conn.release();
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/marks/initiate-session
// Direct Admin (or authorized Faculty/HOD) assessment session initiation
// Creates an initial draft session so status immediately becomes 'Not Entered'
// ─────────────────────────────────────────────────────────────
router.post('/initiate-session', async (req, res) => {
  const conn = await db.getConnection();
  try {
    const authUser = getAuthenticatedUser(req);
    if (!authUser || !authUser.id) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    let staff;
    try {
      staff = await resolveActingStaff(db, authUser.id, authUser.pwf);
    } catch (authErr) {
      return res.status(authErr.status || 401).json({ error: authErr.message || 'Unauthorized authentication context.' });
    }
    if (!staff) {
      return res.status(403).json({ error: 'Unauthorized: User not found in staff registry.' });
    }

    const staffRole = (staff.role || '').toLowerCase();
    const isPrivileged = staffRole === 'admin' || staffRole === 'principal' || staffRole === 'vice_principal';
    const isHod = staffRole === 'hod';

    const { subjectId, classId, sessionLabel = 'internal1' } = req.body;
    if (!subjectId || !classId) {
      return res.status(400).json({ error: 'Missing subjectId or classId.' });
    }
    const validLabels = ['internal1', 'internal2'];
    if (!validLabels.includes(sessionLabel)) {
      return res.status(400).json({ error: "Invalid session label. Must be 'internal1' or 'internal2'." });
    }

    await conn.beginTransaction();

    // 1. Fetch Subject & Class mapping
    const [subRows] = await conn.execute(
      `SELECT s.id AS subject_id, s.code AS subject_code, s.name AS subject_name,
              s.department AS subject_department, s.semester AS subject_semester,
              s.faculty_id, s.total_hours, s.int1_hours, s.int2_hours, s.type AS subject_type,
              c.id AS class_id, c.name AS class_name, c.department AS class_department,
              c.semester AS class_semester, c.year_label, c.section, c.academic_year
       FROM subjects s
       JOIN classes c ON c.id = s.class_id
       WHERE s.id = ? AND c.id = ?`,
      [subjectId, classId]
    );

    if (subRows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ error: 'Subject or class mapping not found.' });
    }
    const subject = subRows[0];

    // 2. Verify faculty allocation
    if (!subject.faculty_id) {
      await conn.rollback();
      return res.status(400).json({
        error: `Cannot initiate session: No faculty is currently allocated to [${subject.subject_code}] ${subject.subject_name}. Please assign faculty first.`
      });
    }

    const [facRows] = await conn.execute('SELECT id, name FROM staffs WHERE id = ?', [subject.faculty_id]);
    if (facRows.length === 0) {
      await conn.rollback();
      return res.status(400).json({
        error: `Cannot initiate session: Allocated faculty '${subject.faculty_id}' was not found in staff registry.`
      });
    }
    const allocatedFaculty = facRows[0];

    // 3. Permission checks
    const isAllocatedFaculty = String(subject.faculty_id) === String(staff.id);
    const isDeptHod = isHod && (
      subject.subject_department === staff.department ||
      subject.class_department === staff.department
    );

    if (!isPrivileged && !isDeptHod && !isAllocatedFaculty) {
      await conn.rollback();
      return res.status(403).json({
        error: 'Unauthorized: You do not have permission to initiate an assessment session for this subject.'
      });
    }

    // 4. Duplicate session prevention
    const [existingSessions] = await conn.execute(
      `SELECT id, status FROM marks_sessions WHERE subject_id = ? AND class_id = ? AND session_label = ?`,
      [subjectId, classId, sessionLabel]
    );
    if (existingSessions.length > 0) {
      await conn.rollback();
      const labelDisplay = sessionLabel === 'internal1' ? 'IA1' : 'IA2';
      return res.status(409).json({
        error: `An assessment session for ${labelDisplay} already exists for ${subject.subject_code} (${subject.class_name}). Duplicate sessions cannot be created.`,
        sessionId: existingSessions[0].id
      });
    }

    // 5. Total hours resolution
    let totalHours = 30;
    if (sessionLabel === 'internal1' && subject.int1_hours > 0) {
      totalHours = subject.int1_hours;
    } else if (sessionLabel === 'internal2' && subject.int2_hours > 0) {
      totalHours = subject.int2_hours;
    } else if (subject.total_hours > 0) {
      totalHours = Math.round(subject.total_hours / 2);
    }

    // 6. Insert new session with status 'draft'
    const [insertRes] = await conn.execute(
      `INSERT INTO marks_sessions (subject_id, class_id, staff_id, session_label, status, total_hours, student_count, avg_score, total_max)
       VALUES (?, ?, ?, ?, 'draft', ?, 0, 0, 50)`,
      [subjectId, classId, subject.faculty_id, sessionLabel, totalHours]
    );
    const sessionId = insertRes.insertId;

    // 7. Audit log
    try {
      await conn.execute(
        `INSERT INTO marks_audit_logs
           (session_id, student_id, component_id, field_name, old_value, new_value, user_id, user_name, action_type)
         VALUES (?, 'ALL', NULL, 'status', 'not_created', 'draft', ?, ?, 'SESSION_INITIATED')`,
        [
          sessionId,
          staff.id,
          staff.name || 'System User'
        ]
      );
    } catch (auditErr) {
      console.warn('marks_audit_logs insert note:', auditErr.message);
    }

    // 8. Notifications
    try {
      const labelDisplay = sessionLabel === 'internal1' ? 'IA1' : 'IA2';
      const actorDisplay = staff.name ? `${staff.name} (${staffRole.toUpperCase()})` : 'Administration';
      await conn.execute(
        `INSERT INTO notifications (target_role, target_department, title, message, link)
         VALUES ('faculty', ?, ?, ?, '/marks-entry')`,
        [
          subject.class_department || subject.subject_department || 'General',
          `${labelDisplay} Assessment Session Initiated`,
          `${labelDisplay} session for [${subject.subject_code}] ${subject.subject_name} (${subject.class_name}) has been initiated by ${actorDisplay}. Mark entry is now available.`
        ]
      );
    } catch (notifErr) {
      console.warn('Notification insert note:', notifErr.message);
    }

    await conn.commit();

    const labelDisplay = sessionLabel === 'internal1' ? 'IA1' : 'IA2';
    res.json({
      success: true,
      message: `${labelDisplay} session initiated successfully for [${subject.subject_code}] ${subject.subject_name} (${subject.class_name}). Session is now available to allocated faculty ${allocatedFaculty.name}.`,
      sessionId,
      session: {
        id: sessionId,
        subjectId,
        classId,
        sessionLabel,
        status: 'draft',
        totalHours,
        facultyName: allocatedFaculty.name
      }
    });
  } catch (err) {
    await conn.rollback();
    console.error('POST /marks/initiate-session error:', err);
    res.status(500).json({ error: 'Failed to initiate assessment session: ' + err.message });
  } finally {
    conn.release();
  }
});

router._resetSchemaCapabilities = () => {
  schemaCapabilities = null;
};

export default router;
